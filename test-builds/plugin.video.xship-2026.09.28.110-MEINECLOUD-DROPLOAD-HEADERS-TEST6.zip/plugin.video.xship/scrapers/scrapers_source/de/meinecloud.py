# -*- coding: UTF-8 -*-

# MeineCloud provider
# Movie4k family database source

from resources.lib.utils import isBlockedHosterFast as isBlockedHoster
from scrapers.modules.meinecloud_shared import get_movie_links, get_series_links
from resources.lib.control import getSetting
from resources.lib.domain_manager import resolve_domain
import base64
import re
from html import unescape
from urllib.parse import quote
import requests
import time
from urllib.parse import urljoin

SITE_IDENTIFIER = 'meinecloud'
SITE_DOMAIN = 'meinecloud.click'
SITE_NAME = SITE_IDENTIFIER.upper()


_MC_UA = ('Mozilla/5.0 (Windows NT 10.0; Win64; x64) '
          'AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36')
_MC_CHARS = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ'


def _mc_log(message):
    try:
        import xbmc
        xbmc.log('[xShip MEINECLOUD-DROP] ' + str(message), xbmc.LOGINFO)
    except Exception:
        pass


def _mc_encode(num, radix):
    if num == 0:
        return '0'
    out = ''
    while num > 0:
        rem = num % radix
        if rem >= len(_MC_CHARS):
            return ''
        out = _MC_CHARS[rem] + out
        num //= radix
    return out


def _mc_unpack_one(block):
    try:
        match = re.search(
            r"}\s*\(\s*'(.*?)'\s*,\s*(\d+)\s*,\s*(\d+)\s*,\s*'(.*?)'\.split\('\|'\)",
            block,
            flags=re.S
        )
        if not match:
            return ''
        payload = match.group(1).replace("\\'", "'")
        radix = int(match.group(2))
        count = int(match.group(3))
        words = match.group(4).split('|')
        mapping = {}
        for index in range(count - 1, -1, -1):
            key = _mc_encode(index, radix)
            if not key:
                continue
            value = words[index] if index < len(words) and words[index] else key
            mapping[key] = value
        return re.sub(r'\b\w+\b', lambda m: mapping.get(m.group(0), m.group(0)), payload)
    except Exception:
        return ''


def _mc_unpack_all(html):
    output = []
    pattern = re.compile(
        r"eval\(function\(p,a,c,k,e,[dr]\)\{[\s\S]*?\.split\('\|'\)[^)]*\)\)",
        flags=re.I
    )
    for match in pattern.finditer(html or ''):
        unpacked = _mc_unpack_one(match.group(0))
        if unpacked:
            output.append(unpacked)
    return '\n'.join(output)


def _mc_find_stream(html):
    flat = ((html or '') + '\n' + _mc_unpack_all(html or '')).replace('\\/', '/')
    flat = unescape(flat)

    match = re.search(r"""https?://[^"'\s\\]+\.m3u8[^"'\s\\]*""", flat, flags=re.I)
    if match:
        return match.group(0)

    for token in re.findall(
        r"""atob\s*\(\s*["']([A-Za-z0-9+/=]{20,})["']\s*\)""",
        html or '',
        flags=re.I
    ):
        try:
            padded = token + ('=' * (-len(token) % 4))
            decoded = base64.b64decode(padded).decode('utf-8', 'ignore').replace('\\/', '/')
            match = re.search(r"""https?://[^"'\s\\]+\.m3u8[^"'\s\\]*""", decoded, flags=re.I)
            if match:
                return match.group(0)
        except Exception:
            pass

    match = re.search(
        r"""(?:file|source|src)\s*:\s*["']([^"']+\.(?:m3u8|mp4)[^"']*)["']""",
        flat,
        flags=re.I
    )
    if match:
        return match.group(1).replace('\\/', '/')

    match = re.search(r"""https?://[^"'\s\\]+\.mp4[^"'\s\\]*""", flat, flags=re.I)
    if match:
        return match.group(0)
    return ''


def _mc_resolve_dropload(url):
    try:
        raw = str(url or '').strip()
        if not raw:
            return ''
        low = raw.lower()
        if 'dropload.' not in low and 'dr0pstream.' not in low and 'dropcdn.' not in low:
            return ''

        clean = raw.split('|', 1)[0].split('?', 1)[0].split('#', 1)[0].rstrip('/')
        match = re.search(r'(?:embed-|/e/|/d/|/)([A-Za-z0-9]+)(?:\.html)?$', clean, flags=re.I)
        if not match:
            _mc_log('file code missing: %s' % raw)
            return ''
        code = match.group(1)

        candidates = [raw.split('|', 1)[0]]
        canonical = 'https://dr0pstream.com/e/%s' % code
        if canonical not in candidates:
            candidates.append(canonical)

        session = requests.Session()
        for page_url in candidates:
            # Match current E2iPlayer JWPLAYER behaviour closely:
            # keep a plain browser UA + root Referer, preserve Session cookies,
            # and do not add Origin/X-Requested-With on this XFileSharing flow.
            headers = {
                'User-Agent': _MC_UA,
                'Referer': 'https://dr0pstream.com/',
                'Accept': 'text/html,application/xhtml+xml,*/*;q=0.8',
            }
            try:
                response = session.get(page_url, headers=headers, timeout=10, allow_redirects=True)
            except Exception as exc:
                _mc_log('GET error %s | %r' % (page_url, exc))
                continue

            html = response.text or ''
            _mc_log('GET status=%s bytes=%s final=%s' % (
                response.status_code, len(html), response.url
            ))
            if response.status_code != 200 or not html:
                continue

            stream = _mc_find_stream(html)

            # Current DropLoad/dr0pstream may first return a short waiting/form page.
            # Follow an iframe/data-embed hop if present, then mimic the site's
            # hidden-form continuation before falling back to ResolveURL.
            if not stream:
                hop = re.search(r'(?:data-embed|iframe\s+src)=["\']([^"\']+)', html, flags=re.I)
                if hop:
                    hop_url = urljoin(response.url, hop.group(1))
                    try:
                        hop_headers = dict(headers)
                        hop_headers['Referer'] = response.url
                        hop_res = session.get(hop_url, headers=hop_headers, timeout=10, allow_redirects=True)
                        hop_html = hop_res.text or ''
                        _mc_log('hop status=%s bytes=%s final=%s' % (
                            hop_res.status_code, len(hop_html), hop_res.url
                        ))
                        if hop_res.status_code == 200 and hop_html:
                            response = hop_res
                            html = hop_html
                            stream = _mc_find_stream(html)
                    except Exception as exc:
                        _mc_log('hop error | %r' % (exc,))

            if not stream and '<form' in (html or '').lower():
                try:
                    form = re.search(r'<form[^>]*>(.*?)</form>', html, flags=re.I | re.S)
                    if form:
                        whole = form.group(0)
                        body = form.group(1)
                        action_m = re.search(r'action\s*=\s*["\']([^"\']+)', whole, flags=re.I)
                        post_url = urljoin(response.url, action_m.group(1)) if action_m else response.url
                        _mc_log('form action_present=%s' % ('yes' if action_m else 'no'))
                        data = {}
                        for tag in re.findall(r'<input[^>]*>', body, flags=re.I):
                            type_m = re.search(r'type\s*=\s*["\']?([^"\'\s>]+)', tag, flags=re.I)
                            kind = (type_m.group(1).lower() if type_m else '')
                            if kind not in ('hidden', 'submit', ''):
                                continue
                            name_m = re.search(r'name\s*=\s*["\']([^"\']+)', tag, flags=re.I)
                            if not name_m:
                                continue
                            value_m = re.search(r'value\s*=\s*["\']([^"\']*)', tag, flags=re.I)
                            value = value_m.group(1) if value_m else ''
                            if name_m.group(1) == 'file_code' and not value:
                                value = code
                            data[name_m.group(1)] = value

                        if data:
                            _mc_log('form detected | fields=%s | action=%s' % (
                                ','.join(sorted(data.keys())), post_url
                            ))
                            time.sleep(6)
                            post_headers = dict(headers)
                            post_headers['Referer'] = 'https://dr0pstream.com/'
                            post_headers.pop('Origin', None)
                            post_headers.pop('X-Requested-With', None)
                            _mc_log('form POST headers=e2i-root-referer cookies=%s' % (
                                len(session.cookies.get_dict()),
                            ))
                            post_res = session.post(
                                post_url,
                                headers=post_headers,
                                data=data,
                                timeout=12,
                                allow_redirects=True
                            )
                            post_html = post_res.text or ''
                            _mc_log('form POST status=%s bytes=%s final=%s' % (
                                post_res.status_code, len(post_html), post_res.url
                            ))
                            if post_res.status_code == 200 and post_html:
                                response = post_res
                                html = post_html
                                stream = _mc_find_stream(html)
                except Exception as exc:
                    _mc_log('form fallback ERROR | %r' % (exc,))

            if not stream:
                _mc_log('no direct stream found for %s' % code)
                continue

            stream = stream.replace('&amp;', '&').strip()
            origin = 'https://%s' % (re.sub(r'^www\.', '', response.url.split('/')[2]))
            stream_headers = {
                'User-Agent': _MC_UA,
                'Referer': response.url,
                'Origin': origin,
            }
            suffix = '&'.join(
                '%s=%s' % (key, quote(value, safe=''))
                for key, value in stream_headers.items()
            )
            _mc_log('native stream found | code=%s | host=%s' % (
                code, stream.split('/')[2] if '://' in stream else 'relative'
            ))
            return stream + '|' + suffix
    except Exception as exc:
        _mc_log('resolver ERROR | %r' % (exc,))
    return ''


class source:
    def __init__(self):
        self.priority = getSetting('provider.' + SITE_IDENTIFIER + '.priority', 100)
        self.language = ['de']
        self.domain = resolve_domain(SITE_IDENTIFIER, SITE_DOMAIN)
        self.base_link = 'https://' + self.domain
        self.sources = []

    def _add_links(self, links, numbered=False, defer_resolve=False):
        seen = set()
        index = 0
        for sUrl in links or []:
            if not sUrl or sUrl in seen:
                continue
            seen.add(sUrl)

            if defer_resolve:
                native_url = _mc_resolve_dropload(sUrl)
                if native_url:
                    index += 1
                    source_name = 'DropLoad'
                    if numbered and index > 1:
                        source_name = '%s(%s)' % (source_name, index)
                    self.sources.append({
                        'source': source_name,
                        'quality': '1080p',
                        'language': 'de',
                        'url': native_url,
                        'direct': True,
                        'priority': int(self.priority),
                        'prioHoster': 100
                    })
                    continue

            try:
                if defer_resolve:
                    isBlocked, hoster, url, prioHoster = isBlockedHoster(sUrl, isResolve=False)
                else:
                    isBlocked, hoster, url, prioHoster = isBlockedHoster(sUrl)
            except TypeError:
                isBlocked, hoster, url, prioHoster = isBlockedHoster(sUrl)

            if defer_resolve and (isBlocked or not url):
                try:
                    from urllib.parse import urlparse
                    hoster = (urlparse(sUrl).hostname or 'MeineCloud').lower()
                except Exception:
                    hoster = 'MeineCloud'
                url = sUrl
                prioHoster = 100
                isBlocked = False
                try:
                    import xbmc
                    xbmc.log('[xShip MEINECLOUD-API] series deferred raw source: %s' % sUrl, xbmc.LOGINFO)
                except Exception:
                    pass

            if isBlocked or not url:
                continue

            index += 1
            source_name = hoster or 'MeineCloud'
            if numbered and index > 1:
                source_name = '%s(%s)' % (source_name, index)

            self.sources.append({
                'source': source_name,
                'quality': '1080p',
                'language': 'de',
                'url': url,
                'direct': False if defer_resolve else True,
                'priority': int(self.priority),
                'prioHoster': prioHoster
            })

    def run(self, titles, year, season=0, episode=0, imdb=''):
        self.sources = []
        try:
            if int(season or 0) == 0:
                self._add_links(get_movie_links(imdb, self.base_link))
            else:
                self._add_links(
                    get_series_links(imdb, int(season), int(episode), self.base_link),
                    numbered=True,
                    defer_resolve=True
                )
            return self.sources
        except Exception:
            return self.sources

    def resolve(self, url):
        return url
