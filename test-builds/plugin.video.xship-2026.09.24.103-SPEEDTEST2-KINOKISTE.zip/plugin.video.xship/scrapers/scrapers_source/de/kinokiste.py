# -*- coding: UTF-8 -*-
import json
import re
import time
import requests
from difflib import SequenceMatcher
from resources.lib.control import getSetting, quote_plus, urlparse
from resources.lib.requestHandler import cRequestHandler
from resources.lib.domain_manager import resolve_domain
from resources.lib import log_utils
from scrapers.modules import cleantitle

SITE_IDENTIFIER = 'kinokiste'
SITE_DOMAIN = 'kinokiste.eu'
SITE_NAME = 'KINOKISTE'
UA = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'


class source:
    def __init__(self):
        self.priority = getSetting('provider.' + SITE_IDENTIFIER + '.priority', 100)
        self.language = ['de', 'en']
        self.domain = resolve_domain(SITE_IDENTIFIER, SITE_DOMAIN)
        self.base_link = 'https://' + self.domain
        self.search_link = self.base_link + '/data/browse/?lang=%s&keyword=%s&year=%s&type=%s&page=1'
        self.imdb_link = self.base_link + '/data/browse/?lang=%s&order_by=new&page=1&imdb=%s'
        self.watch_links = [self.base_link + '/data/watch/?_id=%s', self.base_link + '/data/watch?_id=%s']
        self.sources = []
        self._deadline = 0.0
        self._json_cache = {}
        self._session = requests.Session()
        self._session.headers.update({
            'User-Agent': UA,
            'Accept': 'application/json, text/plain, */*',
            'Accept-Language': 'de-DE,de;q=0.9,en;q=0.8',
            'Referer': self.base_link + '/',
            'Origin': self.base_link,
            'X-Requested-With': 'XMLHttpRequest',
        })

    def _json(self, url):
        if url in self._json_cache:
            return self._json_cache[url]

        # Kinokiste's JSON endpoints are currently intermittent. The generic
        # request handler can wait a long time on a single bad route, so this
        # provider uses a short, provider-local timeout.
        try:
            remaining = self._deadline - time.monotonic() if self._deadline else 4.0
            if remaining <= 0.35:
                return None
            timeout = max(0.8, min(4.0, remaining))
            started = time.monotonic()
            response = self._session.get(url, timeout=timeout, allow_redirects=True)
            elapsed = time.monotonic() - started

            try:
                log_utils.log(
                    '[KINOKISTE-FAST] %.2fs status=%s %s' %
                    (elapsed, response.status_code, url),
                    log_utils.LOGINFO
                )
            except Exception:
                pass

            if response.status_code != 200:
                return None
            data = response.json()
            if isinstance(data, dict):
                self._json_cache[url] = data
                return data
        except Exception as exc:
            try:
                log_utils.log(
                    '[KINOKISTE-FAST] request failed: %s (%s)' % (url, exc),
                    log_utils.LOGINFO
                )
            except Exception:
                pass
        return None

    def _watch(self, media_id):
        for template in self.watch_links:
            data = self._json(template % media_id)
            if data and isinstance(data.get('streams'), list):
                return data
        return None

    @staticmethod
    def _quality(value):
        text = str(value or '').upper()
        if '2160' in text or '4K' in text:
            return '4K'
        if '1080' in text:
            return '1080p'
        if '720' in text:
            return '720p'
        if 'CAM' in text:
            return 'CAM'
        if 'SD' in text:
            return 'SD'
        return 'HD'

    @staticmethod
    def _title_match(candidate, clean_titles):
        cleaned = cleantitle.get(candidate or '')
        if not cleaned:
            return False
        if cleaned in clean_titles:
            return True
        for wanted in clean_titles:
            if not wanted:
                continue
            if min(len(cleaned), len(wanted)) >= 5 and SequenceMatcher(None, cleaned, wanted).ratio() >= 0.92:
                return True
        return False

    def _candidate_matches(self, movie, clean_titles, year, season_num):
        title = str(movie.get('title') or '').strip()
        mid = str(movie.get('_id') or '').strip()
        if not title or not mid:
            return False

        if season_num:
            sm = re.search(r'(?:Staffel|Season)\s*0*(\d+)', title, re.I)
            if not sm or int(sm.group(1)) != season_num:
                return False
            base = re.sub(
                r'\s*[-:]?\s*(?:Staffel|Season)\s*0*\d+.*',
                '', title, flags=re.I
            ).strip()
            return self._title_match(base, clean_titles)

        base = re.sub(r'\s*\(\d{4}\)\s*$', '', title).strip()
        if not self._title_match(base, clean_titles):
            return False
        try:
            item_year = int(movie.get('year') or 0)
            if item_year and year and abs(item_year - int(year)) > 1:
                return False
        except Exception:
            pass
        return True

    def run(self, titles, year, season=0, episode=0, imdb='', hostDict=None):
        self.sources = []
        self._json_cache = {}
        # Hard provider budget. Kinokiste must never hold the complete source
        # search for 30-60 seconds because one API language is unhealthy.
        self._deadline = time.monotonic() + 12.0

        clean_titles = set(cleantitle.get(x) for x in titles or [] if x)
        season_num = int(season or 0)
        episode_num = int(episode or 0)
        media_type = 'tvseries' if season_num > 0 else 'movies'

        search_titles = []
        seen_title = set()
        for value in titles or []:
            value = str(value or '').strip()
            key = cleantitle.get(value)
            if value and key and key not in seen_title:
                seen_title.add(key)
                search_titles.append(value)
        # Two good title variants are enough; xShip/TMDb can otherwise supply
        # several aliases that multiply API timeouts.
        search_titles = search_titles[:2]

        def matching_items(data):
            result = []
            movies = data.get('movies') if isinstance(data, dict) else None
            if not isinstance(movies, list):
                return result
            for movie in movies:
                if not isinstance(movie, dict):
                    continue
                if self._candidate_matches(movie, clean_titles, year, season_num):
                    result.append(movie)
                    if len(result) >= 2:
                        break
            return result

        candidates = []

        # Fast path: one language at a time, preferred order DE -> Multi -> EN.
        # Stop at the first language that actually contains the requested item.
        for lang in ('2', '4', '3'):
            if time.monotonic() >= self._deadline:
                break
            lang_candidates = []
            for title in search_titles:
                if time.monotonic() >= self._deadline:
                    break
                data = self._json(self.search_link % (
                    lang, quote_plus(title), '' if season_num else year, media_type
                ))
                lang_candidates.extend(matching_items(data))
                if lang_candidates:
                    break
            if lang_candidates:
                candidates = lang_candidates[:2]
                break

        # IMDb is a fallback only. Previously it was called for every language
        # before every title search and doubled the request count.
        if not candidates and imdb and time.monotonic() < self._deadline:
            for lang in ('2', '4', '3'):
                if time.monotonic() >= self._deadline:
                    break
                data = self._json(self.imdb_link % (lang, imdb))
                lang_candidates = matching_items(data)
                if lang_candidates:
                    candidates = lang_candidates[:2]
                    break

        per_host = {}
        seen_urls = set()

        for movie in candidates:
            if time.monotonic() >= self._deadline:
                break
            title = str(movie.get('title') or '')
            mid = str(movie.get('_id') or '')
            if not mid:
                continue
            watch = self._watch(mid)
            if not watch:
                continue

            lang_value = str(watch.get('lang') or '')
            language = 'en' if lang_value == '3' or 'Season' in title else 'de'
            info = 'Mehrsprachig' if lang_value == '4' else ('Englisch' if language == 'en' else 'Deutsch')

            for stream in watch.get('streams') or []:
                if season_num and str(stream.get('e') or '').lstrip('0') != str(episode_num):
                    continue
                url = str(stream.get('stream') or '').strip()
                if not url:
                    continue
                if url.startswith('//'):
                    url = 'https:' + url
                if url in seen_urls:
                    continue

                host = (urlparse(url).hostname or '').lower()
                if not host:
                    continue

                bucket = (host, language)
                if per_host.get(bucket, 0) >= 2:
                    continue

                seen_urls.add(url)
                per_host[bucket] = per_host.get(bucket, 0) + 1
                quality = self._quality(stream.get('release') or movie.get('quality'))
                self.sources.append({
                    'source': host,
                    'quality': quality,
                    'language': language,
                    'url': url,
                    'direct': False,
                    'priority': int(self.priority),
                    'prioHoster': 100,
                    'info': info
                })

        try:
            log_utils.log(
                '[KINOKISTE-FAST] finished sources=%s candidates=%s' %
                (len(self.sources), len(candidates)),
                log_utils.LOGINFO
            )
        except Exception:
            pass
        return self.sources

    def resolve(self, url):
        return url
