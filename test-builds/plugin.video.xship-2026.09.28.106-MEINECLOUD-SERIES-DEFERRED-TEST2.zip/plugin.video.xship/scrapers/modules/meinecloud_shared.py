# -*- coding: UTF-8 -*-

import base64
import re
import threading
from html import unescape
from resources.lib.requestHandler import cRequestHandler

UA = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'
DEFAULT_BASE = 'https://meinecloud.click'

_movie_cache = {}
_series_cache = {}
_cache_lock = threading.Lock()


def _unique(values):
    seen = set()
    result = []
    for value in values:
        if value and value not in seen:
            seen.add(value)
            result.append(value)
    return result


def _decode_link_value(value):
    """Decode MeineCloud mirror values when the site stores them as Base64."""
    value = unescape(str(value or '')).strip().replace('\\/', '/')
    if not value:
        return ''

    # Series pages currently expose normal URLs while movie pages expose
    # Base64 strings such as Ly9zdXBlcnZpZGVvLmNjL2Uv... (= //supervideo.cc/e/...).
    if value.startswith(('http://', 'https://', '//', '/')):
        return value

    compact = re.sub(r'\s+', '', value)
    if len(compact) >= 12 and re.fullmatch(r'[A-Za-z0-9_+/=-]+', compact):
        try:
            padded = compact + ('=' * (-len(compact) % 4))
            decoded = base64.b64decode(padded, altchars=b'-_', validate=False).decode('utf-8', 'strict').strip()
            decoded = unescape(decoded).replace('\\/', '/')
            if decoded.startswith(('http://', 'https://', '//', '/')):
                return decoded
        except Exception:
            pass

    return value


def _normalize_link(value, base_link):
    value = _decode_link_value(value)
    if not value:
        return ''
    if value.startswith('//'):
        return 'https:' + value
    if value.startswith('/'):
        return base_link.rstrip('/') + value
    return value


def _attrs(tag):
    return {
        key.lower(): unescape(value)
        for key, _, value in re.findall(
            r'([\w:-]+)\s*=\s*([\'\"])(.*?)\2',
            tag or '',
            flags=re.I | re.S
        )
    }


def _extract_data_links(html, base_link, season=None, episode=None):
    html = html or ''
    result = []

    for tag in re.findall(r'<[^>]+\bdata-link\s*=\s*[\'\"][^>]+>', html, flags=re.I | re.S):
        attrs = _attrs(tag)
        link = attrs.get('data-link')
        if not link:
            continue

        if season is not None and episode is not None:
            label = attrs.get('data-label', '')
            if not re.search(
                r'\bS0*%d\s*[-._ ]?\s*E0*%d\b' % (int(season), int(episode)),
                label,
                flags=re.I
            ):
                continue

        normalized = _normalize_link(link, base_link)
        if normalized:
            result.append(normalized)

    if season is None and not result:
        for link in re.findall(r'\bdata-link\s*=\s*[\'\"]([^\'\"]+)[\'\"]', html, flags=re.I | re.S):
            normalized = _normalize_link(link, base_link)
            if normalized:
                result.append(normalized)

    if season is None and not result:
        for link in re.findall(r'<iframe[^>]+\bsrc\s*=\s*[\'\"]([^\'\"]+)[\'\"]', html, flags=re.I | re.S):
            normalized = _normalize_link(link, base_link)
            low = normalized.lower()
            if not normalized or 'youtube.' in low or 'youtu.be' in low or 'vpns.html' in low:
                continue
            result.append(normalized)

    return _unique(result)


def _request(url, base_link):
    request = cRequestHandler(url, caching=False)
    request.addHeaderEntry('User-Agent', UA)
    request.addHeaderEntry('Referer', base_link.rstrip('/') + '/')
    try:
        request.addHeaderEntry('Origin', base_link.rstrip('/'))
    except Exception:
        pass
    return request.request() or ''


def get_movie_links(imdb, base_link=DEFAULT_BASE):
    base_link = (base_link or DEFAULT_BASE).rstrip('/')
    imdb = str(imdb or '').strip()
    if not imdb:
        return []

    key = (base_link, imdb)
    with _cache_lock:
        if key in _movie_cache:
            return list(_movie_cache[key])

    try:
        html = _request('%s/movie/%s' % (base_link, imdb), base_link)
        links = _extract_data_links(html, base_link)
    except Exception:
        links = []

    # Cache only successful lookups. A transient challenge/empty response
    # must not poison later retries for the whole Kodi process.
    if links:
        with _cache_lock:
            _movie_cache[key] = tuple(links)
    return list(links)


def get_series_links(imdb, season, episode, base_link=DEFAULT_BASE):
    base_link = (base_link or DEFAULT_BASE).rstrip('/')
    imdb = str(imdb or '').strip()
    if not imdb:
        return []

    numeric_imdb = imdb[2:] if imdb.lower().startswith('tt') else imdb
    key = (base_link, numeric_imdb, int(season), int(episode))

    with _cache_lock:
        if key in _series_cache:
            return list(_series_cache[key])

    try:
        html = _request('%s/serial/%s' % (base_link, numeric_imdb), base_link)
        links = _extract_data_links(html, base_link, season=season, episode=episode)
    except Exception:
        links = []

    if links:
        with _cache_lock:
            _series_cache[key] = tuple(links)
    return list(links)


# ---------------------------------------------------------------------------
# xShip 2026-09-28 MeineCloud DeVideoSRC token-API compatibility
# ---------------------------------------------------------------------------
def _xship_mc_base(base_link):
    base = str(base_link or 'https://meinecloud.click').strip().rstrip('/')
    if not base.startswith('http'):
        base = 'https://' + base.lstrip('/')
    return base

def _xship_mc_headers(referer=''):
    return {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36',
        'Accept': 'text/html,application/xhtml+xml,application/json;q=0.9,*/*;q=0.8',
        'Referer': referer or 'https://meinecloud.click/',
    }

def _xship_mc_sources(data):
    out = []
    if not isinstance(data, dict):
        return out
    for src in data.get('sources') or []:
        if not isinstance(src, dict):
            continue
        url = str(src.get('url') or '').strip()
        if url.startswith('//'):
            url = 'https:' + url
        if url.startswith('http') and 'meinecloud' not in url.lower() and url not in out:
            out.append(url)
    return out

def _xship_mc_log(msg):
    try:
        import xbmc
        xbmc.log('[xShip MEINECLOUD-API] ' + str(msg), xbmc.LOGINFO)
    except Exception:
        pass

def get_movie_links(imdb, base_link='https://meinecloud.click'):
    if not imdb:
        return []
    try:
        import re as _re
        import requests as _requests
        base = _xship_mc_base(base_link)
        page_url = base + '/movie/' + str(imdb)
        session = _requests.Session()
        response = session.get(page_url, headers=_xship_mc_headers(base + '/'), timeout=10)
        html = response.text or ''
        _xship_mc_log('movie page status=%s bytes=%s imdb=%s' % (response.status_code, len(html), imdb))
        token = _re.search(r"""token:\s*["']([^"']+)""", html)
        if not token:
            _xship_mc_log('movie token missing imdb=%s' % imdb)
            return []
        api_headers = _xship_mc_headers(page_url)
        api_headers.update({'Origin': base, 'Content-Type': 'application/json', 'Accept': 'application/json'})
        api = session.post(base + '/api/embed-links', headers=api_headers,
                           json={'type': 'movie', 'id': str(imdb), 'token': token.group(1)}, timeout=10)
        try:
            data = api.json()
        except Exception:
            data = {}
        links = _xship_mc_sources(data)
        _xship_mc_log('movie api status=%s sources=%s imdb=%s' % (api.status_code, len(links), imdb))
        return links
    except Exception as exc:
        _xship_mc_log('movie ERROR imdb=%s err=%r' % (imdb, exc))
        return []

def get_series_links(imdb, season, episode, base_link='https://meinecloud.click'):
    if not imdb:
        return []
    try:
        import re as _re
        import requests as _requests
        base = _xship_mc_base(base_link)
        page_url = '%s/serial/%s/%s/%s' % (base, imdb, int(season), int(episode))
        session = _requests.Session()
        response = session.get(page_url, headers=_xship_mc_headers(base + '/'), timeout=10)
        html = response.text or ''
        _xship_mc_log('episode page status=%s bytes=%s imdb=%s S%sE%s' % (response.status_code, len(html), imdb, season, episode))
        def attr(name, default=''):
            m = _re.search(_re.escape(name) + r'="([^"]*)"', html)
            return m.group(1) if m else default
        token = attr('data-resolve-token')
        if not token:
            _xship_mc_log('episode token missing imdb=%s S%sE%s' % (imdb, season, episode))
            return []
        endpoint = attr('data-resolve-endpoint', '/api/resolve')
        if not endpoint.startswith('http'):
            endpoint = base + '/' + endpoint.lstrip('/')
        body = {
            'type': attr('data-type', 'tv'),
            'id': attr('data-id', str(imdb)),
            'season': attr('data-season', str(season)),
            'episode': attr('data-episode', str(episode)),
            'mode': attr('data-mode', 'custom'),
            'token': token,
        }
        api_headers = _xship_mc_headers(page_url)
        api_headers.update({'Origin': base, 'Content-Type': 'application/json', 'Accept': 'application/json'})
        api = session.post(endpoint, headers=api_headers, json=body, timeout=10)
        try:
            data = api.json()
        except Exception:
            data = {}
        links = _xship_mc_sources(data)
        _xship_mc_log('episode api status=%s sources=%s imdb=%s S%sE%s' % (api.status_code, len(links), imdb, season, episode))
        return links
    except Exception as exc:
        _xship_mc_log('episode ERROR imdb=%s S%sE%s err=%r' % (imdb, season, episode, exc))
        return []
