# -*- coding: UTF-8 -*-

# MeineCloud provider
# Movie4k family database source

from resources.lib.utils import isBlockedHosterFast as isBlockedHoster
from scrapers.modules.meinecloud_shared import get_movie_links, get_series_links
from resources.lib.control import getSetting
from resources.lib.domain_manager import resolve_domain
import base64
import re
from html import unescape
from urllib.parse import quote
import requests
import time

SITE_IDENTIFIER = 'meinecloud'
SITE_DOMAIN = 'meinecloud.click'
SITE_NAME = SITE_IDENTIFIER.upper()


_MC_UA = ('Mozilla/5.0 (Windows NT 10.0; Win64; x64) '
          'AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36')
_MC_CHARS = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ'


def _mc_log(message):
    try:
        import xbmc
        xbmc.log('[xShip MEINECLOUD-DROP] ' + str(message), xbmc.LOGINFO)
    except Exception:
        pass


def _mc_encode(num, radix):
    if num == 0:
        return '0'
    out = ''
    while num > 0:
        rem = num % radix
        if rem >= len(_MC_CHARS):
            return ''
        out = _MC_CHARS[rem] + out
        num //= radix
    return out


def _mc_unpack_one(block):
    try:
        match = re.search(
            r"}\s*\(\s*'(.*?)'\s*,\s*(\d+)\s*,\s*(\d+)\s*,\s*'(.*?)'\.split\('\|'\)",
            block,
            flags=re.S
        )
        if not match:
            return ''
        payload = match.group(1).replace("\\'", "'")
        radix = int(match.group(2))
        count = int(match.group(3))
        words = match.group(4).split('|')
        mapping = {}
        for index in range(count - 1, -1, -1):
            key = _mc_encode(index, radix)
            if not key:
                continue
            value = words[index] if index < len(words) and words[index] else key
            mapping[key] = value
        return re.sub(r'\b\w+\b', lambda m: mapping.get(m.group(0), m.group(0)), payload)
    except Exception:
        return ''


def _mc_unpack_all(html):
    output = []
    pattern = re.compile(
        r"eval\(function\(p,a,c,k,e,[dr]\)\{[\s\S]*?\.split\('\|'\)[^)]*\)\)",
        flags=re.I
    )
    for match in pattern.finditer(html or ''):
        unpacked = _mc_unpack_one(match.group(0))
        if unpacked:
            output.append(unpacked)
    return '\n'.join(output)


def _mc_find_stream(html):
    flat = ((html or '') + '\n' + _mc_unpack_all(html or '')).replace('\\/', '/')
    flat = unescape(flat)

    match = re.search(r"""https?://[^"'\s\\]+\.m3u8[^"'\s\\]*""", flat, flags=re.I)
    if match:
        return match.group(0)

    for token in re.findall(
        r"""atob\s*\(\s*["']([A-Za-z0-9+/=]{20,})["']\s*\)""",
        html or '',
        flags=re.I
    ):
        try:
            padded = token + ('=' * (-len(token) % 4))
            decoded = base64.b64decode(padded).decode('utf-8', 'ignore').replace('\\/', '/')
            match = re.search(r"""https?://[^"'\s\\]+\.m3u8[^"'\s\\]*""", decoded, flags=re.I)
            if match:
                return match.group(0)
        except Exception:
            pass

    match = re.search(
        r"""(?:file|source|src)\s*:\s*["']([^"']+\.(?:m3u8|mp4)[^"']*)["']""",
        flat,
        flags=re.I
    )
    if match:
        return match.group(1).replace('\\/', '/')

    match = re.search(r"""https?://[^"'\s\\]+\.mp4[^"'\s\\]*""", flat, flags=re.I)
    if match:
        return match.group(0)
    return ''


def _mc_resolve_dropload(url):
    try:
        raw = str(url or '').strip()
        if not raw:
            return ''
        low = raw.lower()
        if 'dropload.' not in low and 'dr0pstream.' not in low and 'dropcdn.' not in low:
            return ''

        clean = raw.split('|', 1)[0].split('?', 1)[0].split('#', 1)[0].rstrip('/')
        match = re.search(r'(?:embed-|/e/|/d/|/)([A-Za-z0-9]+)(?:\.html)?$', clean, flags=re.I)
        if not match:
            _mc_log('file code missing: %s' % raw)
            return ''
        code = match.group(1)

        session = requests.Session()
        candidates = [
            raw.split('|', 1)[0],
            'https://dr0pstream.com/e/%s' % code,
            'https://dropload.pro/e/%s' % code,
        ]
        seen_pages = set()

        def _headers(referer='https://dr0pstream.com/'):
            return {
                'User-Agent': _MC_UA,
                'Accept': '*/*',
                'Accept-Language': 'de-DE,de;q=0.9,en;q=0.8',
                'Referer': referer,
                'Origin': 'https://dr0pstream.com',
                'X-Requested-With': 'XMLHttpRequest',
            }

        def _cookie_header(html=''):
            cookies = {}
            try:
                cookies.update(session.cookies.get_dict())
            except Exception:
                pass
            for name, value in re.findall(
                r"""\$\.cookie\(\s*['"]([^'"]+)['"]\s*,\s*['"]([^'"]*)['"]""",
                html or '',
                flags=re.I
            ):
                cookies[name] = value
            return '; '.join('%s=%s' % (k, v) for k, v in cookies.items())

        def _try_hidden_form(html, page_url):
            form = re.search(r'<form\b([^>]*)>(.*?)</form>', html or '', flags=re.I | re.S)
            if not form:
                return ''
            attrs, body = form.group(1), form.group(2)
            action = re.search(r"""action\s*=\s*['"]([^'"]+)""", attrs, flags=re.I)
            action_url = action.group(1) if action else page_url
            if action_url.startswith('/'):
                action_url = 'https://dr0pstream.com' + action_url
            fields = {}
            for tag in re.findall(r'<input\b[^>]*>', body, flags=re.I):
                nm = re.search(r"""name\s*=\s*['"]([^'"]+)""", tag, flags=re.I)
                if not nm:
                    continue
                vl = re.search(r"""value\s*=\s*['"]([^'"]*)""", tag, flags=re.I)
                fields[nm.group(1)] = vl.group(1) if vl else ''
            if fields.get('file_code', None) == '':
                fields['file_code'] = code
            captcha = bool(re.search(r'(?:g-recaptcha|cf-turnstile|turnstile|data-sitekey)', html or '', flags=re.I))
            _mc_log('form detected | fields=%s | captcha=%s' % (sorted(fields.keys()), captcha))
            try:
                time.sleep(6)
                h = _headers(page_url)
                ck = _cookie_header(html)
                if ck:
                    h['Cookie'] = ck
                resp = session.post(action_url, data=fields, headers=h, timeout=10, allow_redirects=True)
                _mc_log('form POST status=%s bytes=%s final=%s' % (resp.status_code, len(resp.text or ''), resp.url))
                return resp.text or ''
            except Exception as exc:
                _mc_log('form POST error | %r' % (exc,))
                return ''

        def _try_ds2(html, page_url):
            unpacked = _mc_unpack_all(html or '')
            if not unpacked:
                strict = re.search(
                    r"""eval\(function\(p,a,c,k,e,d\)\{.*?return p\}\('(.+?)',(\d+),(\d+),'(.+?)'\.split\('\|'\)\)\)""",
                    html or '',
                    flags=re.I | re.S
                )
                if strict:
                    try:
                        payload = strict.group(1).replace("\\'", "'").replace('\\\\', '\\')
                        radix = int(strict.group(2))
                        count = int(strict.group(3))
                        words = strict.group(4).split('|')
                        mapping = {}
                        for idx in range(count - 1, -1, -1):
                            key = _mc_encode(idx, radix)
                            if key:
                                mapping[key] = words[idx] if idx < len(words) and words[idx] else key
                        unpacked = re.sub(r'\b[0-9A-Za-z]+\b', lambda m: mapping.get(m.group(0), m.group(0)), payload)
                    except Exception:
                        unpacked = ''

            cookies = _cookie_header(html)
            long_numbers = re.findall(r'\b\d{10}\b', unpacked or '')
            hashes = re.findall(r'\b[a-f0-9]{32}\b', unpacked or '', flags=re.I)
            view_ids = re.findall(r'\b\d{6,7}\b', unpacked or '')
            _mc_log('ds2 parse | unpacked=%s | cookies=%s | long=%s | hash=%s | view=%s' % (
                len(unpacked or ''), bool(cookies), len(long_numbers), len(hashes), len(view_ids)
            ))

            if long_numbers and hashes:
                dynamic_hash = '%s-%s' % (long_numbers[-1], hashes[-1])
                view_id = view_ids[-1] if view_ids else '303030'
                beacon = 'https://dr0pstream.com/dl?op=view&file_code=%s&hash=%s&view_id=%s&adb=0' % (
                    code, dynamic_hash, view_id
                )
                try:
                    h = _headers(page_url)
                    if cookies:
                        h['Cookie'] = cookies
                    br = session.get(beacon, headers=h, timeout=10, allow_redirects=True)
                    _mc_log('ds2 beacon status=%s bytes=%s view=%s' % (br.status_code, len(br.text or ''), view_id))
                    stream = _mc_find_stream((unpacked or '') + '\n' + (html or '') + '\n' + (br.text or ''))
                    if stream:
                        return stream
                    rr = session.get(page_url, headers=h, timeout=10, allow_redirects=True)
                    _mc_log('ds2 reload status=%s bytes=%s' % (rr.status_code, len(rr.text or '')))
                    stream = _mc_find_stream(rr.text or '')
                    if stream:
                        return stream
                except Exception as exc:
                    _mc_log('ds2 error | %r' % (exc,))
            return ''

        for page_url in candidates:
            if page_url in seen_pages:
                continue
            seen_pages.add(page_url)
            try:
                response = session.get(page_url, headers=_headers(), timeout=10, allow_redirects=True)
            except Exception as exc:
                _mc_log('GET error %s | %r' % (page_url, exc))
                continue

            html = response.text or ''
            flags = []
            if re.search(r'(?:g-recaptcha|cf-turnstile|turnstile|data-sitekey)', html, flags=re.I):
                flags.append('captcha')
            if '<form' in html.lower():
                flags.append('form')
            if 'function(p,a,c,k,e' in html:
                flags.append('packer')
            _mc_log('GET status=%s bytes=%s final=%s flags=%s' % (
                response.status_code, len(html), response.url, ','.join(flags) or '-'
            ))
            if response.status_code != 200 or not html:
                continue

            stream = _mc_find_stream(html)
            if not stream:
                stream = _try_ds2(html, response.url)

            if not stream and '<form' in html.lower():
                posted = _try_hidden_form(html, response.url)
                if posted:
                    stream = _mc_find_stream(posted)
                    if not stream:
                        stream = _try_ds2(posted, response.url)

            if not stream:
                _mc_log('no direct stream found for %s' % code)
                continue

            stream = stream.replace('&amp;', '&').replace('\\/', '/').strip()
            if 'dropcdn.io' in stream:
                stream = stream.replace('r1.dropcdn.io', 'ds2.dropcdn.io').replace('_o/', '/').replace('_o.m3u8', '.m3u8')
                if 'srv=' not in stream:
                    stream += ('&' if '?' in stream else '?') + 'srv=ds2i'

            cookie = _cookie_header(html)
            stream_headers = {
                'User-Agent': _MC_UA,
                'Referer': 'https://dr0pstream.com/',
                'Origin': 'https://dr0pstream.com',
            }
            if cookie:
                stream_headers['Cookie'] = cookie
            suffix = '&'.join(
                '%s=%s' % (key, quote(value, safe=''))
                for key, value in stream_headers.items()
            )
            _mc_log('native stream found | code=%s | host=%s | cookie=%s' % (
                code, stream.split('/')[2] if '://' in stream else 'relative', bool(cookie)
            ))
            return stream + '|' + suffix
    except Exception as exc:
        _mc_log('resolver ERROR | %r' % (exc,))
    return ''


class source:
    def __init__(self):
        self.priority = getSetting('provider.' + SITE_IDENTIFIER + '.priority', 100)
        self.language = ['de']
        self.domain = resolve_domain(SITE_IDENTIFIER, SITE_DOMAIN)
        self.base_link = 'https://' + self.domain
        self.sources = []

    def _add_links(self, links, numbered=False, defer_resolve=False):
        seen = set()
        index = 0
        for sUrl in links or []:
            if not sUrl or sUrl in seen:
                continue
            seen.add(sUrl)

            if defer_resolve:
                native_url = _mc_resolve_dropload(sUrl)
                if native_url:
                    index += 1
                    source_name = 'DropLoad'
                    if numbered and index > 1:
                        source_name = '%s(%s)' % (source_name, index)
                    self.sources.append({
                        'source': source_name,
                        'quality': '1080p',
                        'language': 'de',
                        'url': native_url,
                        'direct': True,
                        'priority': int(self.priority),
                        'prioHoster': 100
                    })
                    continue

            try:
                if defer_resolve:
                    isBlocked, hoster, url, prioHoster = isBlockedHoster(sUrl, isResolve=False)
                else:
                    isBlocked, hoster, url, prioHoster = isBlockedHoster(sUrl)
            except TypeError:
                isBlocked, hoster, url, prioHoster = isBlockedHoster(sUrl)

            if defer_resolve and (isBlocked or not url):
                try:
                    from urllib.parse import urlparse
                    hoster = (urlparse(sUrl).hostname or 'MeineCloud').lower()
                except Exception:
                    hoster = 'MeineCloud'
                url = sUrl
                prioHoster = 100
                isBlocked = False
                try:
                    import xbmc
                    xbmc.log('[xShip MEINECLOUD-API] series deferred raw source: %s' % sUrl, xbmc.LOGINFO)
                except Exception:
                    pass

            if isBlocked or not url:
                continue

            index += 1
            source_name = hoster or 'MeineCloud'
            if numbered and index > 1:
                source_name = '%s(%s)' % (source_name, index)

            self.sources.append({
                'source': source_name,
                'quality': '1080p',
                'language': 'de',
                'url': url,
                'direct': False if defer_resolve else True,
                'priority': int(self.priority),
                'prioHoster': prioHoster
            })

    def run(self, titles, year, season=0, episode=0, imdb=''):
        self.sources = []
        try:
            if int(season or 0) == 0:
                self._add_links(get_movie_links(imdb, self.base_link))
            else:
                self._add_links(
                    get_series_links(imdb, int(season), int(episode), self.base_link),
                    numbered=True,
                    defer_resolve=True
                )
            return self.sources
        except Exception:
            return self.sources

    def resolve(self, url):
        return url
