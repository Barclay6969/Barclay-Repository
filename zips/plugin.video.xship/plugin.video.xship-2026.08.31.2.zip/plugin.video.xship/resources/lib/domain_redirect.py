# -*- coding: utf-8 -*-
"""xShip provider-domain redirect observer.

Uses redirects that xShip already encounters. It never performs an additional
network request. If a request starts on a configured provider root domain and
ends on a different safe hostname, the provider setting and SITE_DOMAIN are
updated immediately.
"""
import json
import os
import re
from urllib.parse import urlparse

import xbmc
import xbmcaddon
import xbmcvfs

_ADDON = xbmcaddon.Addon()
_WRONG_HOSTS = {
    'vodafone.de', 'www.vodafone.de', 'notice.cuii.info',
    'site-maps.cc', 'drei.at', 'www.drei.at', 'streamingunity.biz',
}


def _log(message, level=xbmc.LOGINFO):
    try:
        xbmc.log('[xShip DomainAuto] %s' % message, level)
    except Exception:
        pass


def _host(value):
    value = str(value or '').strip()
    if not value:
        return ''
    try:
        if '://' not in value:
            value = 'https://' + value
        return (urlparse(value).hostname or '').strip().lower().rstrip('.')
    except Exception:
        return ''


def _same_host(a, b):
    a = _host(a)
    b = _host(b)
    if not a or not b:
        return False
    return a == b or a.removeprefix('www.') == b.removeprefix('www.')


def _read_provider(path):
    try:
        with open(path, 'r', encoding='utf-8') as fh:
            text = fh.read()
        ident = re.search(r"(?m)^\s*SITE_IDENTIFIER\s*=\s*(['\"])([^'\"]+)\1", text)
        domain = re.search(r"(?m)^\s*SITE_DOMAIN\s*=\s*(['\"])([^'\"]+)\1", text)
        if ident and domain:
            return ident.group(2).strip(), domain.group(2).strip(), text, domain
    except Exception:
        pass
    return None, None, None, None


def _write_site_domain(path, text, match, domain):
    try:
        updated = text[:match.start(2)] + domain + text[match.end(2):]
        tmp = path + '.domain-auto.tmp'
        with open(tmp, 'w', encoding='utf-8', newline='') as fh:
            fh.write(updated)
        os.replace(tmp, path)
        return True
    except Exception as exc:
        _log('scraper write failed %s: %s' % (path, exc), xbmc.LOGWARNING)
        return False


def _update_state(provider, final_host):
    """Keep the existing bidirectional sync state aligned with this runtime update."""
    try:
        profile = xbmcvfs.translatePath(_ADDON.getAddonInfo('profile'))
        if profile and not xbmcvfs.exists(profile):
            xbmcvfs.mkdirs(profile)
        state_path = os.path.join(profile, 'domain_sync.json')
        state = {}
        if xbmcvfs.exists(state_path):
            f = xbmcvfs.File(state_path, 'r')
            try:
                state = json.loads(f.read() or '{}')
            finally:
                f.close()
            if not isinstance(state, dict):
                state = {}
        state[provider] = final_host
        f = xbmcvfs.File(state_path, 'w')
        try:
            f.write(json.dumps(state, ensure_ascii=False, indent=2, sort_keys=True))
        finally:
            f.close()
    except Exception as exc:
        _log('state update failed for %s: %s' % (provider, exc), xbmc.LOGDEBUG)


def update_from_redirect(original_url, final_url):
    """Persist a safe provider-domain change observed in an actual HTTP redirect.

    Returns a list of provider identifiers that were updated.
    """
    original_host = _host(original_url)
    final_host = _host(final_url)
    if not original_host or not final_host or _same_host(original_host, final_host):
        return []
    if final_host in _WRONG_HOSTS:
        _log('blocked redirect ignored: %s -> %s' % (original_host, final_host), xbmc.LOGWARNING)
        return []

    addon_path = xbmcvfs.translatePath(_ADDON.getAddonInfo('path'))
    scraper_dir = os.path.join(addon_path, 'scrapers', 'scrapers_source', 'de')
    if not os.path.isdir(scraper_dir):
        return []

    updated_providers = []
    try:
        names = os.listdir(scraper_dir)
    except Exception:
        return []

    for name in names:
        if not name.endswith('.py') or name.startswith('__'):
            continue
        path = os.path.join(scraper_dir, name)
        provider, source_domain, text, match = _read_provider(path)
        if not provider:
            continue
        setting_id = 'provider.%s.domain' % provider
        try:
            configured = (_ADDON.getSetting(setting_id) or source_domain or '').strip()
        except Exception:
            configured = source_domain or ''

        # Critical safety rule: only redirects whose ORIGINAL host is already the
        # provider's configured/root domain may teach xShip a new provider domain.
        # Hoster/embed/API redirects therefore cannot overwrite provider settings.
        if not _same_host(original_host, configured):
            continue

        try:
            _ADDON.setSetting(setting_id, final_host)
        except Exception as exc:
            _log('setting update failed for %s: %s' % (provider, exc), xbmc.LOGWARNING)
            continue
        if source_domain and not _same_host(source_domain, final_host):
            _write_site_domain(path, text, match, final_host)
        _update_state(provider, final_host)
        updated_providers.append(provider)
        _log('%s redirect: %s -> %s' % (provider, original_host, final_host))

    return updated_providers
