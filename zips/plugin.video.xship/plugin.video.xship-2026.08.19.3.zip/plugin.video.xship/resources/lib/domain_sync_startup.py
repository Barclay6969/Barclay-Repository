# -*- coding: utf-8 -*-
import json
import os
import re

import xbmc
import xbmcaddon
import xbmcvfs

_ADDON = xbmcaddon.Addon()

def _log(msg):
    try:
        xbmc.log('[xShip DomainSync] %s' % msg, xbmc.LOGINFO)
    except Exception:
        pass

def _read_state(path):
    try:
        if xbmcvfs.exists(path):
            f = xbmcvfs.File(path)
            raw = f.read()
            f.close()
            data = json.loads(raw or '{}')
            return data if isinstance(data, dict) else {}
    except Exception:
        pass
    return {}

def _write_state(path, state):
    try:
        parent = os.path.dirname(path)
        if parent and not xbmcvfs.exists(parent):
            xbmcvfs.mkdirs(parent)
        f = xbmcvfs.File(path, 'w')
        f.write(json.dumps(state, indent=2, sort_keys=True))
        f.close()
    except Exception as exc:
        _log('state write failed: %s' % exc)

def _get_site_domain(path):
    try:
        with open(path, 'r', encoding='utf-8') as fh:
            text = fh.read()
        m = re.search(r'(?m)^\s*SITE_DOMAIN\s*=\s*([\'\"])([^\'\"]+)\1', text)
        return m.group(2).strip() if m else None
    except Exception:
        return None

def _set_site_domain(path, domain):
    try:
        with open(path, 'r', encoding='utf-8') as fh:
            text = fh.read()
        new, n = re.subn(
            r'(?m)^(\s*SITE_DOMAIN\s*=\s*)([\'\"])([^\'\"]+)(\2)',
            lambda m: m.group(1) + m.group(2) + domain + m.group(4),
            text,
            count=1,
        )
        if n:
            with open(path, 'w', encoding='utf-8') as fh:
                fh.write(new)
            return True
    except Exception as exc:
        _log('scraper write failed for %s: %s' % (path, exc))
    return False

def sync_domains():
    addon_path = xbmcvfs.translatePath(_ADDON.getAddonInfo('path'))
    profile = xbmcvfs.translatePath(_ADDON.getAddonInfo('profile'))
    state_path = os.path.join(profile, 'domain_sync.json')
    state = _read_state(state_path)

    scraper_dir = os.path.join(addon_path, 'scrapers', 'scrapers_source', 'de')
    if not os.path.isdir(scraper_dir):
        return

    changed = False
    for name in os.listdir(scraper_dir):
        if not name.endswith('.py') or name.startswith('__'):
            continue
        provider = name[:-3]
        scraper_path = os.path.join(scraper_dir, name)
        scraper_domain = _get_site_domain(scraper_path)
        if not scraper_domain:
            continue
        setting_id = 'provider.%s.domain' % provider
        try:
            user_domain = (_ADDON.getSetting(setting_id) or '').strip()
        except Exception:
            continue
        last_domain = str(state.get(provider, '') or '').strip()

        if provider == 'megakino' and scraper_domain == 'megakino15.com' and user_domain == 'megakino14.com':
            _ADDON.setSetting(setting_id, scraper_domain)
            user_domain = scraper_domain
            _log('megakino migration: settings -> %s' % scraper_domain)

        if not last_domain:
            if not user_domain:
                _ADDON.setSetting(setting_id, scraper_domain)
                user_domain = scraper_domain
            elif user_domain != scraper_domain:
                if _set_site_domain(scraper_path, user_domain):
                    scraper_domain = user_domain
                    _log('%s first sync: scraper <- settings (%s)' % (provider, user_domain))
        else:
            scraper_changed = scraper_domain != last_domain
            user_changed = bool(user_domain) and user_domain != last_domain
            if scraper_changed and not user_changed:
                _ADDON.setSetting(setting_id, scraper_domain)
                user_domain = scraper_domain
                _log('%s update sync: settings <- scraper (%s)' % (provider, scraper_domain))
            elif user_changed and not scraper_changed:
                if _set_site_domain(scraper_path, user_domain):
                    scraper_domain = user_domain
                    _log('%s manual sync: scraper <- settings (%s)' % (provider, user_domain))
            elif scraper_changed and user_changed and user_domain != scraper_domain:
                if _set_site_domain(scraper_path, user_domain):
                    scraper_domain = user_domain
                    _log('%s conflict: user override preserved (%s)' % (provider, user_domain))

        effective = user_domain or scraper_domain
        if state.get(provider) != effective:
            state[provider] = effective
            changed = True

    if changed or not xbmcvfs.exists(state_path):
        _write_state(state_path, state)

if __name__ == '__main__':
    sync_domains()
