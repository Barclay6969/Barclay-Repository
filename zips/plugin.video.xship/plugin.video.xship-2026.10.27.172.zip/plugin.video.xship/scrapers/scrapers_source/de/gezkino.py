# -*- coding: utf-8 -*-
from resources.lib.control import getSetting
from resources.lib import gezkino
SITE_IDENTIFIER = 'gezkino'
SITE_DOMAIN = 'raw.githubusercontent.com'
SITE_NAME = 'GEZ-KiNO'

class source:
    def __init__(self):
        self.priority = getSetting('provider.gezkino.priority', 100)
        self.language = ['de']

    def run(self, titles, year, season=0, episode=0, imdb='', hostDict=None):
        if season or episode or not titles:
            return []
        data, _ = gezkino.load()
        result, seen = [], set()
        for movie in gezkino.matching(data, titles, year):
            url = movie['video_url']
            if url in seen:
                continue
            seen.add(url)
            result.append({'source': 'GEZ-KiNO / ' + (movie.get('channel') or 'Mediathek'),
                           'quality': 'SD', 'language': 'de', 'url': url, 'direct': True,
                           'priority': int(self.priority), 'prioHoster': 1})
        if not result:
            from resources.lib import mediathekview_search
            for movie in mediathekview_search.search(titles, year):
                result.append({'source': 'GEZ-KiNO / MVW / ' + movie['channel'],
                               'quality': movie['quality'], 'language': 'de',
                               'url': movie['video_url'], 'direct': True,
                               'priority': int(self.priority), 'prioHoster': 1})
        return result

    def resolve(self, url):
        return url
