# -*- coding: utf-8 -*-
"""Title-search fallback using the public MediathekViewWeb API."""
import re
import time
import unicodedata
import requests
import xbmc
from urllib.parse import urlsplit

API = 'https://mediathekviewweb.de/api/query'


def normalize(value):
    value = unicodedata.normalize('NFKD', value.casefold().replace('ß', 'ss'))
    return ''.join(c for c in value if c.isalnum())


def title_matches(actual, titles):
    # Accept catalogue annotations, but not sequels or merely similar titles.
    variants = [actual, actual.split('|', 1)[0].strip()]
    variants += [re.sub(r'\s*\((?:19|20)\d{2}\)\s*$', '', v) for v in variants[:]]
    for value in variants:
        if normalize(value) in {normalize(t) for t in titles if t}:
            return True
        for title in titles:
            if title and value.casefold().startswith(title.casefold() + ' - '):
                return True
    return False


def search(titles, year):
    started = time.monotonic()
    result, seen = [], set()
    # German title is supplied first by xShip. One request keeps fallback bounded.
    query = next((t for t in titles if t), '')
    if not query:
        return []
    payload = {'queries': [{'fields': ['title'], 'query': query}],
               'size': 100, 'sortBy': 'timestamp', 'sortOrder': 'desc'}
    try:
        response = requests.post(API, json=payload, headers={'Content-Type': 'text/plain'}, timeout=(3, 6))
        response.raise_for_status()
        rows = response.json().get('result', {}).get('results', [])
        if not isinstance(rows, list):
            return []
        for movie in rows:
            if not isinstance(movie, dict):
                continue
            title = str(movie.get('title') or '')
            if not title_matches(title, titles):
                continue
            if re.search(r'trailer|vorschau|making.of|gebärdensprache|audiodeskription|hörfassung|hörfilm', title, re.I):
                continue
            try:
                if float(movie.get('duration') or 0) < 3600:
                    continue
            except (ValueError, TypeError):
                continue
            # Broadcast timestamps are not production years. Compare only explicit years.
            production = re.search(r'\b(?:Spielfilm|Fernsehfilm|Produktion)\s+(?:Deutschland|Frankreich|USA|Österreich|Schweiz)\s+((?:19|20)\d{2})\b', str(movie.get('description') or ''), re.I)
            if production and str(year).isdigit() and int(production.group(1)) != int(year):
                continue
            stream = movie.get('url_video_hd') or movie.get('url_video') or movie.get('url_video_low')
            if not isinstance(stream, str) or urlsplit(stream).scheme not in ('https', 'http') or stream in seen:
                continue
            seen.add(stream)
            result.append({'title': title, 'channel': movie.get('channel') or 'Mediathek',
                           'video_url': stream, 'quality': 'HD' if movie.get('url_video_hd') else 'SD'})
        xbmc.log('[xShip GEZ-MVW] query=%s rows=%s matched=%s time=%.2fs' % (query, len(rows), len(result), time.monotonic()-started), xbmc.LOGINFO)
    except Exception as exc:
        xbmc.log('[xShip GEZ-MVW] query=%s failed=%s time=%.2fs' % (query, type(exc).__name__, time.monotonic()-started), xbmc.LOGWARNING)
    return result
