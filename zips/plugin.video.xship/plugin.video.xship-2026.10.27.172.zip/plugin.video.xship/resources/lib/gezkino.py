# -*- coding: utf-8 -*-
"""GEZ-KiNO catalogue adapter. Data source: Chrisophy/GEZ-KiNO movies.json."""
import json
import os
import tempfile
import time
from urllib.parse import urlencode, urlsplit
import requests
import xbmc
import xbmcaddon
import xbmcgui
import xbmcplugin
import xbmcvfs

CATALOGUE = 'https://raw.githubusercontent.com/Chrisophy/GEZ-KiNO/refs/heads/main/movies.json'
TTL = 86400


def valid_url(url):
    return isinstance(url, str) and urlsplit(url).scheme in ('https', 'http') and bool(urlsplit(url).hostname)


def load(force=False):
    folder = xbmcvfs.translatePath(xbmcaddon.Addon().getAddonInfo('profile'))
    os.makedirs(folder, exist_ok=True)
    path = os.path.join(folder, 'gezkino-movies.json')
    old = []
    try:
        with open(path, encoding='utf-8') as f:
            old = json.load(f)
        if not isinstance(old, list):
            old = []
        if not force and old and time.time() - os.path.getmtime(path) < TTL:
            return old, False
    except (OSError, ValueError):
        pass
    temp = None
    try:
        response = requests.get(CATALOGUE, timeout=(5, 10))
        response.raise_for_status()
        data = response.json()
        if not isinstance(data, list) or not data or not all(isinstance(m, dict) for m in data):
            raise ValueError('Ungueltige Filmliste')
        data = [m for m in data if m.get('title') and valid_url(m.get('video_url'))]
        if not data:
            raise ValueError('Keine abspielbaren Eintraege')
        fd, temp = tempfile.mkstemp(prefix='gezkino-', dir=folder)
        with os.fdopen(fd, 'w', encoding='utf-8') as f:
            json.dump(data, f, ensure_ascii=False)
        os.replace(temp, path)
        return data, True
    except Exception as exc:
        xbmc.log('[xShip GEZ-KiNO] Aktualisierung fehlgeschlagen: %s' % exc, xbmc.LOGWARNING)
        return old, False
    finally:
        if temp and os.path.exists(temp):
            os.unlink(temp)


def matching(data, titles, year):
    from scrapers.modules import cleantitle
    wanted = {cleantitle.get(t) for t in titles if t}
    for movie in data:
        if cleantitle.get(movie.get('title', '')) not in wanted:
            continue
        actual = str(movie.get('year') or '')
        if year and actual.isdigit() and str(year).isdigit() and int(actual) != int(year):
            continue
        if valid_url(movie.get('video_url')):
            yield movie


def route(params):
    import sys
    handle = int(sys.argv[1])
    base = sys.argv[0]
    mode = params.get('mode', '')
    if mode == 'play':
        url = params.get('url', '')
        if not valid_url(url):
            xbmcplugin.setResolvedUrl(handle, False, xbmcgui.ListItem())
            return
        item = xbmcgui.ListItem(path=url)
        item.setInfo('video', {'title': params.get('title', ''), 'mediatype': 'movie'})
        xbmcplugin.setResolvedUrl(handle, True, item)
        return
    if mode == 'sync':
        data, updated = load(force=True)
        text = '%s Filme aktualisiert.' % len(data) if updated else 'Aktualisierung fehlgeschlagen. Vorhandene Liste bleibt erhalten.'
        xbmcgui.Dialog().notification('GEZ-KiNO', text)
        return
    def add(label, **kwargs):
        item = xbmcgui.ListItem(label=label)
        xbmcplugin.addDirectoryItem(handle, base + '?' + urlencode(dict(action='gezkino', **kwargs)), item, kwargs.get('mode') != 'sync')
    if not mode:
        for label, value in [('Alle Filme', 'list'), ('Filme suchen', 'search'), ('Genres', 'genres'), ('Jahre', 'years'), ('Mediathek aktualisieren', 'sync')]:
            add(label, mode=value)
        xbmcplugin.endOfDirectory(handle, cacheToDisc=False)
        return
    data, _ = load()
    if mode in ('genres', 'years'):
        values = {str(m.get('year')) for m in data if str(m.get('year', '')).isdigit()} if mode == 'years' else {g for m in data for g in (m.get('genres_list') or [])}
        for value in sorted(values, reverse=mode == 'years'):
            add(value, mode='list', **{('year' if mode == 'years' else 'genre'): value})
    else:
        query = ''
        if mode == 'search':
            query = xbmcgui.Dialog().input('GEZ-KiNO: Film suchen').strip().casefold()
            if not query:
                xbmcplugin.endOfDirectory(handle)
                return
        xbmcplugin.setContent(handle, 'movies')
        for m in sorted(data, key=lambda m: m['title'].casefold()):
            if query and query not in m['title'].casefold():
                continue
            if params.get('year') and str(m.get('year')) != params['year']:
                continue
            if params.get('genre') and params['genre'] not in (m.get('genres_list') or []):
                continue
            label = m['title'] + (' (%s)' % m['year'] if m.get('year') else '')
            item = xbmcgui.ListItem(label=label)
            info = {'title': m['title'], 'plot': m.get('plot') or '', 'mediatype': 'movie', 'genre': m.get('genres_list') or []}
            if str(m.get('year', '')).isdigit():
                info['year'] = int(m['year'])
            item.setInfo('video', info)
            item.setArt({'poster': m.get('thumb') or '', 'thumb': m.get('thumb') or ''})
            item.setProperty('IsPlayable', 'true')
            url = base + '?' + urlencode({'action': 'gezkino', 'mode': 'play', 'url': m['video_url'], 'title': m['title']})
            xbmcplugin.addDirectoryItem(handle, url, item, False)
        if not data:
            xbmcgui.Dialog().notification('GEZ-KiNO', 'Keine Filmliste verfuegbar. Bitte erneut aktualisieren.')
    xbmcplugin.endOfDirectory(handle, cacheToDisc=False)
