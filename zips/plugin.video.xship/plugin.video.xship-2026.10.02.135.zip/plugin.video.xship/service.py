# -*- coding: utf-8 -*-
import os
import runpy
import xbmc
import xbmcaddon
import xbmcgui
import xbmcvfs

BUILD_VERSION = '2026.10.02.135'
LOG_PREFIX = '[xShip Changelog]'

def log(message, level=xbmc.LOGINFO):
    try:
        xbmc.log('%s %s' % (LOG_PREFIX, message), level)
    except Exception:
        pass

def read_file(path):
    try:
        if not xbmcvfs.exists(path):
            return ''
        fh = xbmcvfs.File(path)
        data = fh.read()
        fh.close()
        return data or ''
    except Exception as exc:
        log('read failed: %s' % exc, xbmc.LOGWARNING)
        return ''

def write_file(path, data):
    try:
        fh = xbmcvfs.File(path, 'w')
        fh.write(data)
        fh.close()
        return True
    except Exception as exc:
        log('write failed: %s' % exc, xbmc.LOGWARNING)
        return False

addon = xbmcaddon.Addon('plugin.video.xship')
profile = xbmcvfs.translatePath(addon.getAddonInfo('profile'))
addon_path = xbmcvfs.translatePath(addon.getAddonInfo('path'))
marker = os.path.join(profile, 'changelog_seen_build.txt')
changelog = os.path.join(addon_path, 'changelog.txt')

log('wrapper started build=%s' % BUILD_VERSION)

try:
    if not xbmcvfs.exists(profile):
        xbmcvfs.mkdirs(profile)

    seen = read_file(marker).strip()
    log('marker=%s' % (seen or '<none>'))

    if seen != BUILD_VERSION:
        # Delay enough that Kodi and possible update dialogs have settled.
        xbmc.sleep(8000)
        text = read_file(changelog).strip()
        if text:
            log('opening popup')
            xbmcgui.Dialog().textviewer('xShip – Neuigkeiten / Changelog', text)
            log('popup closed')
            write_file(marker, BUILD_VERSION)
        else:
            log('changelog.txt empty or missing', xbmc.LOGWARNING)
    else:
        log('popup already shown for this build')
except Exception as exc:
    log('popup error: %s' % exc, xbmc.LOGERROR)

legacy_service = os.path.join(addon_path, 'service_xship.py')
log('starting original xShip service')
runpy.run_path(legacy_service, run_name='__main__')
