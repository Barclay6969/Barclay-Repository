# -*- coding: UTF-8 -*-
import concurrent.futures
import json
import re
from resources.lib.requestHandler import cRequestHandler
from resources.lib.utils import isBlockedHosterFast as isBlockedHoster
from resources.lib.control import getSetting, quote_plus
from scrapers.modules import cleantitle
from scrapers.modules.meinecloud_shared import get_movie_links
from resources.lib.domain_manager import resolve_domain

SITE_IDENTIFIER = 'kinoking'
SITE_DOMAIN = 'kinoking.cc'
SITE_NAME = SITE_IDENTIFIER.upper()

class source:
    def __init__(self):
        self.priority = getSetting('provider.' + SITE_IDENTIFIER + '.priority', 100)
        self.language = ['de']
        self.domain = resolve_domain(SITE_IDENTIFIER, SITE_DOMAIN)
        self.base_link = 'https://' + self.domain
        self.search_link = self.base_link + '/index.php?search=%s'
        self.sources = []

    @staticmethod
    def _attrs(tag):
        return {k.lower(): v for k, q, v in re.findall(r'([\w:-]+)\s*=\s*([\'"])(.*?)\2', tag or '', re.I | re.S)}

    @staticmethod
    def _title_match(candidate, wanted):
        candidate = re.sub(r'\s*\(\d{4}\)\s*$', '', str(candidate or '')).strip()
        cur = cleantitle.get(candidate)
        if not cur:
            return False
        if cur in wanted:
            return True
        return any(x and min(len(cur), len(x)) >= 6 and (cur.startswith(x) or x.startswith(cur)) for x in wanted)

    def _search_results(self, html, want_series):
        out = []
        for card in re.findall(r'<[^>]+\bfav-data-source\b[^>]*>', html or '', re.I | re.S):
            a = self._attrs(card)
            mid, typ, title = a.get('data-id',''), a.get('data-type','').lower(), a.get('data-title','')
            if not mid or not title:
                continue
            if want_series and typ and typ != 'series':
                continue
            if not want_series and typ and typ != 'movie':
                continue
            out.append((mid, title))
        if out:
            return out
        pat = r'onclick=["\']playContent\([\'"]?(\d+)' if want_series else r'onclick=["\']playMovie\((\d+)\)'
        for m in re.finditer(pat, html or '', re.I):
            chunk = html[m.end():m.end()+500]
            tm = re.search(r'(?:alt|title)=["\']([^"\']+)', chunk, re.I)
            if tm:
                out.append((m.group(1), tm.group(1)))
        return out

    def _series_links(self, media_id, season, episode):
        try:
            html = cRequestHandler(
                self.base_link + '/series.php?id=%s&season=%s' % (media_id, int(season)),
                caching=False
            ).request() or ''
        except Exception:
            return []

        episode_id = ''
        m = re.search(r'const\s+allEpisodesData\s*=\s*(\[.*?\])\s*;\s*let\s+watchedEpisodes', html, re.I | re.S)
        if m:
            try:
                for item in json.loads(m.group(1)):
                    if int(item.get('season_number') or 0) == int(season) and int(item.get('episode_number') or 0) == int(episode):
                        episode_id = str(item.get('id') or '')
                        break
            except Exception:
                pass
        if not episode_id:
            ids = re.findall(r'playEpisode\([\'"]?(\d+)', html, re.I)
            idx = int(episode) - 1
            if 0 <= idx < len(ids):
                episode_id = ids[idx]
        if not episode_id:
            return []

        try:
            raw = cRequestHandler(
                self.base_link + '/api/episode-navigation.php?episode_id=%s' % episode_id,
                caching=False
            ).request()
            data = json.loads(raw) if raw else {}
        except Exception:
            return []

        links = data.get('links') or []
        if isinstance(links, str):
            links = [links]
        out, seen = [], set()
        for value in links:
            if isinstance(value, dict):
                value = value.get('url') or value.get('link') or ''
            url = str(value or '').replace('\\/', '/').strip()
            if url.startswith('//'):
                url = 'https:' + url
            if url and url not in seen:
                seen.add(url); out.append(url)
        return out

    def run(self, titles, year, season=0, episode=0, imdb='', hostDict=None):
        self.sources = []
        wanted = set(cleantitle.get(x) for x in (titles or []) if x)
        candidates, seen_ids = [], set()

        for raw_title in titles or []:
            try:
                html = cRequestHandler(self.search_link % quote_plus(raw_title), caching=True).request() or ''
            except Exception:
                continue
            for mid, title in self._search_results(html, int(season or 0) > 0):
                if mid in seen_ids or not self._title_match(title, wanted):
                    continue
                seen_ids.add(mid); candidates.append(mid)
                if len(candidates) >= 2:
                    break
            if candidates:
                break

        links = []
        if int(season or 0) > 0:
            for mid in candidates:
                links.extend(self._series_links(mid, int(season), int(episode)))
        else:
            self.list = []
            pages = [self.base_link + '/movie.php?id=%s' % mid for mid in candidates]
            if pages:
                with concurrent.futures.ThreadPoolExecutor() as ex:
                    concurrent.futures.wait([ex.submit(self.chk_year, p, year) for p in pages])
            links = list(self.list)

        seen = set()
        for link in links:
            if not link or link in seen:
                continue
            seen.add(link)
            resolve_links = [link]
            if 'meinecloud.click/movie/' in link:
                try:
                    resolve_links = get_movie_links(link.rstrip('/').rsplit('/', 1)[-1] or imdb) or []
                except Exception:
                    resolve_links = []
            for u in resolve_links:
                if u.startswith('//'):
                    u = 'https:' + u
                elif u.startswith('/'):
                    u = self.base_link + u
                try:
                    blocked, hoster, clean_url, prio = isBlockedHoster(u)
                except Exception:
                    continue
                if blocked or not clean_url:
                    continue
                self.sources.append({'source': hoster, 'quality': 'HD', 'language': 'de',
                                     'url': clean_url, 'direct': True,
                                     'priority': int(self.priority), 'prioHoster': prio})
                if len(self.sources) >= 12:
                    return self.sources
        return self.sources

    def resolve(self, url):
        return url

    def chk_year(self, url, year):
        try:
            html = cRequestHandler(url).request() or ''
            ym = re.search(r'<title>.*?(\d{4})', html, re.I | re.S)
            if ym and year and int(ym.group(1)) != int(year):
                return
            im = re.search(r'<iframe.*?src=["\']([^"\']+)', html, re.I | re.S)
            if im:
                self.list.append(im.group(1))
        except Exception:
            pass
