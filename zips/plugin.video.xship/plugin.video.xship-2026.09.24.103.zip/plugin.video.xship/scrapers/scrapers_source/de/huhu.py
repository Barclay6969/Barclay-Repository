# -*- coding: UTF-8 -*-
import base64
import json
from urllib.parse import urlparse
try:
    import requests
except Exception:
    requests = None
from resources.lib.control import getSetting
from resources.lib.requestHandler import cRequestHandler
from resources.lib.utils import isBlockedHosterFast as isBlockedHoster

SITE_IDENTIFIER = 'huhu'
SITE_DOMAIN = 'www.huhu.to'
SITE_NAME = 'HUHU'
UA = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'
_TMDB_FALLBACK = base64.b64decode('ZWRkZTZiNWU0MTI0NmFiNzlhMjY5N2NkMTI1ZTE3ODE=').decode()

class source:
    def __init__(self):
        self.priority = getSetting('provider.' + SITE_IDENTIFIER + '.priority', 100)
        self.language = ['de', 'en']
        self.domain = SITE_DOMAIN
        self.base_link = 'https://' + self.domain
        self.source_link = self.base_link + '/mediaurl-source.json'
        self.sources = []

    def _json(self, url):
        try:
            req = cRequestHandler(url, caching=True)
            req.addHeaderEntry('User-Agent', UA)
            payload = req.request()
            return json.loads(payload) if payload else None
        except Exception:
            return None

    def _tmdb_id(self, imdb, is_series):
        if not imdb:
            return None
        try:
            key = getSetting('api.tmdb') or _TMDB_FALLBACK
            data = self._json('https://api.themoviedb.org/3/find/%s?api_key=%s&external_source=imdb_id' % (imdb, key))
            items = data.get('tv_results' if is_series else 'movie_results') if isinstance(data, dict) else []
            return items[0].get('id') if items else None
        except Exception:
            return None

    def _post_source(self, payload):
        headers = {'User-Agent': UA, 'Accept': 'application/json, text/plain, */*',
                   'Content-Type': 'application/json; charset=utf-8',
                   'Origin': self.base_link, 'Referer': self.base_link + '/'}
        if requests is not None:
            try:
                r = requests.post(self.source_link, data=json.dumps(payload), headers=headers, timeout=12)
                if r.status_code == 200:
                    data = r.json()
                    return data if isinstance(data, list) else []
            except Exception:
                pass
        try:
            from urllib.request import Request, urlopen
            req = Request(self.source_link, data=json.dumps(payload).encode('utf-8'), headers=headers, method='POST')
            with urlopen(req, timeout=12) as response:
                data = json.loads(response.read().decode('utf-8', 'replace'))
                return data if isinstance(data, list) else []
        except Exception:
            return []

    @staticmethod
    def _quality(item):
        text = ' '.join(str(item.get(k) or '') for k in ('tag','name','url')).lower()
        if '2160' in text or '4k' in text: return '4K'
        if '1440' in text: return '1440p'
        if '1080' in text: return '1080p'
        if '960' in text: return '960p'
        if '800' in text: return '800p'
        if '720' in text: return '720p'
        if '480' in text or '360' in text: return 'SD'
        return 'HD'

    @staticmethod
    def _language(item):
        vals = item.get('languages') or []
        if isinstance(vals, str): vals = [vals]
        val = str(vals[0] if vals else 'de').lower()
        if val.startswith('en'): return 'en'
        return 'de'

    def run(self, titles, year, season=0, episode=0, imdb='', hostDict=None):
        self.sources = []
        tmdb = self._tmdb_id(imdb, int(season or 0) > 0)
        if not tmdb:
            return self.sources
        payload = {'language':'de','region':'DE',
                   'type':'series' if int(season or 0) > 0 else 'movie',
                   'ids':{'tmdb_id':int(tmdb)},'name':''}
        if int(season or 0) > 0:
            payload['episode'] = {'ids':{},'season':int(season),'episode':int(episode)}
        seen, per_host = set(), {}
        for item in self._post_source(payload):
            if not isinstance(item, dict) or item.get('type') != 'url':
                continue
            raw = str(item.get('url') or '').strip()
            if not raw.startswith(('http://','https://')) or raw in seen:
                continue
            seen.add(raw)
            try:
                blocked, hoster, clean_url, prio = isBlockedHoster(raw, isResolve=False)
            except Exception:
                hoster = (urlparse(raw).hostname or SITE_NAME).replace('www.','')
                blocked, clean_url, prio = False, raw, 100
            if blocked or not clean_url:
                continue
            lang = self._language(item)
            hk = (str(hoster).lower(), lang)
            if per_host.get(hk,0) >= 2:
                continue
            per_host[hk] = per_host.get(hk,0)+1
            self.sources.append({'source':hoster,'quality':self._quality(item),'language':lang,
                                 'url':clean_url,'direct':False,'debridonly':False,
                                 'info':str(item.get('name') or ''),
                                 'priority':int(self.priority),'prioHoster':prio})
            if len(self.sources) >= 12:
                break
        return self.sources

    def resolve(self, url):
        return url
