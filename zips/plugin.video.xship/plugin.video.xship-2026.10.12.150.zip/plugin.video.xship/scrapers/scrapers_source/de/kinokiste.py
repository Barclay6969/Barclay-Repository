# -*- coding: UTF-8 -*-
import json
import re
from difflib import SequenceMatcher
from resources.lib.control import getSetting, setSetting, quote_plus, urlparse
from resources.lib.requestHandler import cRequestHandler
from resources.lib.domain_manager import resolve_domain
from scrapers.modules import cleantitle
from resources.lib import log_utils

SITE_IDENTIFIER = 'kinokiste'
SITE_DOMAIN = 'kinokiste.club'
SITE_NAME = 'KINOKISTE'
UA = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'
LEGACY_DOMAINS = ('kinokiste.eu', 'www.kinokiste.eu', 'kinokiste.cloud', 'www.kinokiste.cloud')


class source:
    def __init__(self):
        self.priority = getSetting('provider.' + SITE_IDENTIFIER + '.priority', 100)
        self.language = ['de', 'en']
        self.domain = resolve_domain(SITE_IDENTIFIER, SITE_DOMAIN)
        if self.domain in LEGACY_DOMAINS:
            self.domain = SITE_DOMAIN
            setSetting('provider.' + SITE_IDENTIFIER + '.domain', self.domain)
        self.base_link = 'https://' + self.domain
        self.search_link = self.base_link + '/data/browse/?lang=%s&keyword=%s&year=%s&type=%s&page=1'
        self.imdb_link = self.base_link + '/data/browse/?lang=%s&order_by=new&page=1&imdb=%s'
        self.watch_links = [self.base_link + '/data/watch/?_id=%s', self.base_link + '/data/watch?_id=%s']
        self.sources = []
        self._network_failed = False

    def _json(self, url):
        try:
            req = cRequestHandler(url, caching=True, request_timeout=4)
            req.addHeaderEntry('User-Agent', UA)
            req.addHeaderEntry('Referer', self.base_link + '/')
            req.addHeaderEntry('Origin', self.base_link)
            req.addHeaderEntry('X-Requested-With', 'XMLHttpRequest')
            data = req.request()
            if not data or data in ('SEITE NICHT ERREICHBAR', 'URL FEHLER', 'TIMEOUT', 'CLOUDFLARE-SCHUTZ AKTIV'):
                self._network_failed = True
                return None
            return json.loads(data)
        except Exception:
            self._network_failed = True
            return None

    def _watch(self, media_id):
        for template in self.watch_links:
            data = self._json(template % media_id)
            if data and isinstance(data.get('streams'), list):
                return data
        return None

    @staticmethod
    def _quality(value):
        text = str(value or '').upper()
        if '2160' in text or '4K' in text:
            return '4K'
        if '1080' in text:
            return '1080p'
        if '720' in text:
            return '720p'
        if 'CAM' in text:
            return 'CAM'
        if 'SD' in text:
            return 'SD'
        return 'HD'

    @staticmethod
    def _title_match(candidate, clean_titles):
        cleaned = cleantitle.get(candidate or '')
        if not cleaned:
            return False
        if cleaned in clean_titles:
            return True
        for wanted in clean_titles:
            if not wanted:
                continue
            if min(len(cleaned), len(wanted)) >= 5 and SequenceMatcher(None, cleaned, wanted).ratio() >= 0.92:
                return True
        return False

    def _candidate_matches(self, movie, clean_titles, year, season_num):
        title = str(movie.get('title') or '').strip()
        mid = str(movie.get('_id') or '').strip()
        if not title or not mid:
            return False

        if season_num:
            sm = re.search(r'(?:Staffel|Season)\s*0*(\d+)', title, re.I)
            if not sm or int(sm.group(1)) != season_num:
                return False
            base = re.sub(
                r'\s*[-:]?\s*(?:Staffel|Season)\s*0*\d+.*',
                '', title, flags=re.I
            ).strip()
            return self._title_match(base, clean_titles)

        base = re.sub(r'\s*\(\d{4}\)\s*$', '', title).strip()
        if not self._title_match(base, clean_titles):
            return False
        try:
            item_year = int(movie.get('year') or 0)
            if item_year and year and abs(item_year - int(year)) > 1:
                return False
        except Exception:
            pass
        return True

    def run(self, titles, year, season=0, episode=0, imdb='', hostDict=None):
        self.sources = []
        self._network_failed = False
        clean_titles = set(cleantitle.get(x) for x in titles or [] if x)
        season_num = int(season or 0)
        episode_num = int(episode or 0)
        media_type = 'tvseries' if season_num > 0 else 'movies'

        candidates = []
        seen_ids = set()
        for lang in ('4', '2', '3'):
            lang_candidates = []
            raw = []

            if imdb:
                data = self._json(self.imdb_link % (lang, imdb))
                if self._network_failed:
                    log_utils.log('[KINOKISTE-FASTFAIL] transport failed on %s; abort provider' % self.domain, log_utils.LOGINFO)
                    return self.sources
                raw.extend(data.get('movies') if data and isinstance(data.get('movies'), list) else [])

            for title in titles or []:
                data = self._json(self.search_link % (
                    lang, quote_plus(title), '' if season_num else year, media_type
                ))
                if self._network_failed:
                    log_utils.log('[KINOKISTE-FASTFAIL] transport failed on %s; abort provider' % self.domain, log_utils.LOGINFO)
                    return self.sources
                raw.extend(data.get('movies') if data and isinstance(data.get('movies'), list) else [])

            for movie in raw:
                mid = str(movie.get('_id') or '')
                if not mid or mid in seen_ids:
                    continue
                if not self._candidate_matches(movie, clean_titles, year, season_num):
                    continue
                seen_ids.add(mid)
                lang_candidates.append(movie)
                if len(lang_candidates) >= 2:
                    break

            candidates.extend(lang_candidates)

        per_host = {}
        seen_urls = set()

        for movie in candidates:
            title = str(movie.get('title') or '')
            mid = str(movie.get('_id') or '')
            watch = self._watch(mid)
            if self._network_failed:
                log_utils.log('[KINOKISTE-FASTFAIL] watch transport failed; stop provider', log_utils.LOGINFO)
                return self.sources
            if not watch:
                continue

            lang_value = str(watch.get('lang') or '')
            language = 'en' if lang_value == '3' or 'Season' in title else 'de'
            info = 'Mehrsprachig' if lang_value == '4' else ('Englisch' if language == 'en' else 'Deutsch')

            for stream in watch.get('streams') or []:
                if season_num and str(stream.get('e') or '').lstrip('0') != str(episode_num):
                    continue
                url = str(stream.get('stream') or '').strip()
                if not url:
                    continue
                if url.startswith('//'):
                    url = 'https:' + url
                if url in seen_urls:
                    continue

                host = (urlparse(url).hostname or '').lower()
                if not host:
                    continue

                bucket = (host, language)
                if per_host.get(bucket, 0) >= 2:
                    continue

                seen_urls.add(url)
                per_host[bucket] = per_host.get(bucket, 0) + 1
                quality = self._quality(stream.get('release') or movie.get('quality'))
                self.sources.append({
                    'source': host,
                    'quality': quality,
                    'language': language,
                    'url': url,
                    'direct': False,
                    'priority': int(self.priority),
                    'prioHoster': 100,
                    'info': info
                })

        return self.sources

    def resolve(self, url):
        return url
