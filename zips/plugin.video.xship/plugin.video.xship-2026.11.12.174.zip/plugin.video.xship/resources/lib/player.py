

#2021-11-22
#edit 2026-05-18

import sys, re, time, json
import hashlib,os,codecs
from sqlite3 import dbapi2 as database
import xbmc, xbmcplugin
from resources.lib.control import translatePath
from resources.lib import log_utils, control, playcountDB
import xmlrpc.client as _xmlrpclib
from io import BytesIO as _io

# eventuell zur späteren verwendung als meta
#_params = dict(parse_qsl(sys.argv[2].replace('?',''))) if len(sys.argv) > 1 else dict()

PLAYBACK_START_TIMEOUT = 60
PLAYBACK_STALL_TIMEOUT = 90

class player(xbmc.Player):
    def __init__(self, *args, **kwargs):
        xbmc.Player.__init__(self, *args, **kwargs)
        self.streamFinished = False
        self.totalTime = 0
        self.currentTime = 0
        self.playcount = 0
        self.watcher_control = False
        self.playback_started = False
        self.playback_failed = False
        self.user_stopped = False
        self._playback_ended = False
        self._playback_cleanup_done = False
        self._trakt_identity = None
        self.isdebug = True if control.getSetting('status.debug') == 'true' else False
        # Startup-Busy wird bewusst vom Player verwaltet. setResolvedUrl() kann
        # einen zuvor geoeffneten Kodi-Busy-Dialog wieder schliessen, obwohl
        # InputStream/Player den Stream noch vorbereitet.
        self._av_started = False
        self._hls_prebuffer = None
        self._hls_status_control = None
        self._hls_status_window = None
        self._hls_status_failed = False


    def _openStartupBusy(self):
        """Native Kodi-Ladeanzeige bis zum echten AV-Start sichtbar halten."""
        try:
            if self._av_started or self.isPlayingVideo():
                return
            if not control.visible():
                control.busy()
            # ActivateWindow() wird asynchron an die GUI uebergeben. Kurz warten,
            # damit der Skin mindestens einen Frame zeichnen kann.
            for _ in range(6):
                if self._av_started or self.isPlayingVideo() or control.visible():
                    break
                xbmc.sleep(50)
        except:
            pass


    def _closeStartupBusy(self):
        """Beide Kodi-Busy-Varianten sicher schliessen."""
        try:
            control.execute('Dialog.Close(busydialognocancel,true)')
            control.execute('Dialog.Close(busydialog,true)')
        except:
            pass


    def _notifyHlsBufferStatus(self):
        if self._hls_prebuffer is None or control.getSetting('playback.hls_buffer_notifications') != 'true':
            return
        try:
            import xbmcgui
            used, limit, hits = self._hls_prebuffer.status()
            xbmcgui.Dialog().notification('xShip HLS-Puffer',
                'Aktuell %.1f MB gepuffert (max. %d MB)' % (used / 1048576., limit // 1048576),
                time=3000, sound=False)
        except Exception:
            pass

    def onPlayBackPaused(self):
        # Only a user pause triggers a toast; never startup, refill or resume.
        self._notifyHlsBufferStatus()

    def _updateHlsBufferStatus(self):
        if self._hls_status_failed:
            return
        if (self._hls_prebuffer is None or not self._isPlaybackPaused()
                or control.getSetting('playback.hls_buffer_status') != 'true'):
            self._removeHlsBufferStatus()
            return
        try:
            import xbmcgui
            if self._hls_status_control is None:
                window = xbmcgui.Window(12005)
                label = xbmcgui.ControlLabel(20, max(20, window.getHeight() - 120),
                    max(100, window.getWidth() - 40), 35, '', font='font13',
                    textColor='FFFFFFFF', shadowColor='FF000000')
                window.addControl(label)
                label.setVisibleCondition('Window.IsActive(fullscreenvideo)')
                self._hls_status_window, self._hls_status_control = window, label
            used, limit, hits = self._hls_prebuffer.status()
            self._hls_status_control.setLabel('xShip HLS-Puffer: %.1f / %d MB  |  Cache-Treffer: %d' %
                (used / 1048576., limit // 1048576, hits))
        except Exception as error:
            self._hls_status_failed = True
            log_utils.log('[HLS-PREBUFFER] overlay unavailable; notification fallback (%s)' % type(error).__name__, log_utils.LOGWARNING)
            self._removeHlsBufferStatus()

    def _removeHlsBufferStatus(self):
        label, window = self._hls_status_control, self._hls_status_window
        self._hls_status_control = self._hls_status_window = None
        if label is not None and window is not None:
            try:
                window.removeControl(label)
            except Exception:
                pass

    def _closeHlsPrebuffer(self):
        self._removeHlsBufferStatus()
        proxy, self._hls_prebuffer = self._hls_prebuffer, None
        if proxy:
            try:
                proxy.close()
            except Exception:
                pass

    def run(self, title, url, meta, source=None, direct_play=False):
        import xbmc
        try:
            self.meta = meta
            self.mediatype = meta['mediatype']
            self.title = meta['title']
            self.year = str(meta['year']) if 'year' in meta else ''
            if meta['mediatype'] == 'movie':
                self.name = title + ' (%s)' % meta['year'] if meta.get('year', False) else title
            else:
                self.name = title + ' S%02dE%02d' % (int(meta['season']), int(meta['episode']))

            self.imdb = meta.get('imdb_id') or meta.get('imdbnumber') or None
            self.number_of_seasons = meta['number_of_seasons'] if 'number_of_seasons' in meta else None
            self.season = meta['season'] if 'season' in meta else None
            self.number_of_episodes = meta['number_of_episodes'] if 'number_of_episodes' in meta else None
            self.episode = meta['episode'] if 'episode' in meta else None

            self.playcount = meta['playcount'] if 'playcount' in meta else 0
            self.offset = bookmarks().get(self.name)

            from glob import glob
            os.chdir(os.path.join(control.translatePath('special://database/')))
            self.videoDB = os.path.join(control.translatePath('special://database/'), sorted(glob("MyVideos*.db"), reverse=True)[0])

            self.fileID = self.getVideoDB()

            plot = control.unquote(meta['plot']) if 'plot' in meta else ''

            Info = {'plot': plot}
            if 'imdbnumber' in meta: Info.setdefault('IMDBNumber', meta['imdbnumber'])
            if meta['mediatype'] == 'movie':
                Info.setdefault('OriginalTitle', meta['title'])
                Info.setdefault('year', meta['year'])
            else:
                Info.setdefault('TVshowtitle', meta['title'])
                Info.setdefault('Season', self.season)
                Info.setdefault('Episode', self.episode)

            if meta['mediatype'] == 'movie':
                item = control.item(label=self.title)
            else:
                item = control.item(label=self.name)

            # Display provenance only; bookmarks, Trakt and database identity
            # continue to use the original title and metadata above.
            display_title = self.title if meta['mediatype'] == 'movie' else self.name
            if source:
                hoster = str(source.get('source') or '').strip().upper()
                provider = str(source.get('provider') or '').strip().upper()
                provenance = ' @ '.join(value for value in (hoster, provider) if value)
                if provenance:
                    display_title += ' | ' + provenance
            item.setLabel(display_title)
            if int(xbmc.getInfoLabel("System.BuildVersion").split(".")[0]) >= 20:
                item.getVideoInfoTag().setTitle(display_title)
            Info['title'] = display_title

            # TS: video/mp2t
            # HLS: application/x-mpegURL or application/vnd.apple.mpegurl
            # Dash: application/dash+xml
            kodiver = int(xbmc.getInfoLabel("System.BuildVersion").split(".")[0])
            # Header (url|User-Agent=...&Referer=...) zuerst abtrennen. maxsplit=1,
            # damit URLs mit mehreren | nicht crashen (Fix ggue 0.9er .split('|')).
            strhdr = None
            if '|' in url:
                url, strhdr = url.split('|', 1)
            # Preserve the 150 demuxer choice even when the proxy URL has a
            # .m3u8 suffix. In particular VixStream remains on native FFmpeg.
            from resources.lib.stream_playback import is_gxplayer_hls
            gxplayer_hls = is_gxplayer_hls(url)
            use_adaptive = '.m3u' in url or '.mpd' in url or gxplayer_hls
            hls_stream = '.m3u' in url or gxplayer_hls
            if gxplayer_hls:
                log_utils.log('[GXPLAYER-HLS] extensionless HLS: InputStream Adaptive enabled', log_utils.LOGINFO)
            if control.getSetting('playback.hls_prebuffer_test') == 'true':
                try:
                    from resources.lib.stream_playback import manifest_kind
                    hls_stream = gxplayer_hls or manifest_kind(url, strhdr) == 'hls'
                    if hls_stream:
                        from resources.lib.hls_prebuffer import HLSPrebuffer
                        proxy = HLSPrebuffer(strhdr,
                            lambda message: log_utils.log(message, log_utils.LOGINFO),
                            cache_mb=control.getSetting('playback.hls_prebuffer_mb'))
                        original_url = url
                        try:
                            url = proxy.start(url)
                            self._hls_prebuffer = proxy
                        except Exception:
                            proxy.close()
                            url = original_url
                            raise
                except Exception:
                    log_utils.log('[HLS-PREBUFFER] detection/startup failed; original playback path', log_utils.LOGWARNING)
            # HLS UND DASH komplett ueber InputStream Adaptive (wie 0.9er).
            # ISA-Auto-Install passiert beim Kodi-Start im service.py, nicht hier.
            if use_adaptive:
                item.setProperty("inputstream", "inputstream.adaptive")
                item.setProperty('inputstream.adaptive.config', '{"ssl_verify_peer":false}')
                if '.mpd' in url:
                    if kodiver < 21: item.setProperty('inputstream.adaptive.manifest_type', 'mpd')
                    item.setMimeType('application/dash+xml')
                else:
                    if kodiver < 21: item.setProperty('inputstream.adaptive.manifest_type', 'hls')
                    item.setMimeType('application/x-mpegURL')
                item.setContentLookup(False)
                if strhdr:
                    item.setProperty('inputstream.adaptive.stream_headers', strhdr)
                    if kodiver > 19: item.setProperty('inputstream.adaptive.manifest_headers', strhdr)
            else:
                if self._hls_prebuffer is not None:
                    item.setMimeType('application/vnd.apple.mpegurl')
                    item.setContentLookup(False)
                # Sonstige (mp4 etc.): Header ggf. wieder anhaengen, sonst clean durchreichen.
                if strhdr:
                    url = url + '|' + strhdr
            item.setPath(url)
            item.setProperty('IsPlayable', 'true')
            self._setPlaybackMetadata(item, meta, display_title, kodiver)

            # Sofort Feedback geben. Wichtig: Nach setResolvedUrl()/play()
            # nochmals pruefen und ggf. neu oeffnen, weil Kodi den vorherigen
            # Busy-Dialog beim Player-Handoff selbst schliessen kann.
            self._publishTraktIdentity()
            self._openStartupBusy()
            if int(sys.argv[1]) > 0 and not direct_play:
                xbmcplugin.setResolvedUrl(int(sys.argv[1]), True, item)
            else:
                xbmc.Player().play(url, item)

            # Dem Kodi-GUI/Player kurz Zeit fuer den Handoff geben. Falls der
            # AV-Start inzwischen schon kam, verhindert _av_started ein Reopen.
            xbmc.sleep(120)
            self._openStartupBusy()

            self.keepPlaybackAlive()
            return
        except:
            self.playback_failed = True
            self._clearTraktIdentity()
            self._closeHlsPrebuffer()
            self._closeStartupBusy()
            return


    def _publishTraktIdentity(self):
        # script.trakt reads this window property for non-library streams.
        # A ListItem IMDb tag alone is not read by its fallback identification.
        import xbmcgui
        imdb = str(self.imdb or '').strip()
        if not re.fullmatch(r'tt[0-9]+', imdb):
            log_utils.log('[xShip Trakt] no valid IMDb ID for direct identification', log_utils.LOGWARNING)
            return
        self._trakt_identity = json.dumps({'imdb': imdb})
        xbmcgui.Window(10000).setProperty('script.trakt.ids', self._trakt_identity)
        log_utils.log('[xShip Trakt] direct identity published: %s (%s)' %
                      (imdb, self.mediatype), log_utils.LOGINFO)

    def _clearTraktIdentity(self):
        if not self._trakt_identity:
            return
        import xbmcgui
        window = xbmcgui.Window(10000)
        # Do not clear a different add-on's newer playback identity.
        if window.getProperty('script.trakt.ids') == self._trakt_identity:
            window.clearProperty('script.trakt.ids')
        self._trakt_identity = None


    def _setPlaybackMetadata(self, item, meta, display_title, kodiver):
        """Give playback monitors the media identity on every Kodi version."""
        info = {
            'title': display_title,
            'originaltitle': meta.get('originaltitle') or self.title,
            'mediatype': 'movie' if self.mediatype == 'movie' else 'episode',
            'plot': control.unquote(meta.get('plot') or ''),
        }
        imdb = meta.get('imdb_id') or meta.get('imdbnumber') or self.imdb
        if imdb:
            info['imdbnumber'] = str(imdb)
        if self.mediatype != 'movie':
            info['tvshowtitle'] = meta.get('tvshowtitle') or self.title
            for key in ('season', 'episode'):
                if meta.get(key) is not None:
                    info[key] = int(meta[key])
        if str(meta.get('year') or '').isdigit():
            info['year'] = int(meta['year'])
        item.setArt({key: meta[key] for key in ('poster', 'fanart') if meta.get(key)})
        if kodiver <= 19:
            item.setInfo(type='Video', infoLabels=info)
        else:
            from resources.lib.listitem import ListItemInfoTag
            tag = ListItemInfoTag(item, 'video')
            tag.set_info(info)
        log_utils.log('[xShip Playback] metadata: type=%s imdb=%s season=%s episode=%s' %
                      (info['mediatype'], imdb or '-', info.get('season', '-'),
                       info.get('episode', '-')), log_utils.LOGINFO)


    def keepPlaybackAlive(self):
        if self.isdebug: log_utils.log('Start - keepPlaybackAlive', log_utils.LOGINFO)
        started = False
        monitor = xbmc.Monitor()
        for _ in range(0, PLAYBACK_START_TIMEOUT):
            if monitor.abortRequested() or self.streamFinished:
                break
            if self._av_started:
                started = True
                self.playback_started = True
                break
            monitor.waitForAbort(1.0)

        if not started:
            self._clearTraktIdentity()
            self._closeHlsPrebuffer()
            self.playback_failed = True
            self._closeStartupBusy()
            self._stopFailedPlayback()
            log_utils.log('[xShip Playback] Playback start timeout/abort after max. %s seconds: %s' %
                          (PLAYBACK_START_TIMEOUT, getattr(self, 'name', 'unbekannt')), log_utils.LOGWARNING)
            if self.streamFinished:
                self._finishPlaybackOutsideCallback()
            if self.isdebug: log_utils.log('Ende - keepPlaybackAlive (not started)', log_utils.LOGINFO)
            return

        try:
            playcountDB.createEntry(self.mediatype, self.title, self.name, self.imdb, self.number_of_seasons, self.season, self.number_of_episodes, self.episode)
        except:
            pass

        self.watcher_control = False
        stopped_without_callback = 0
        last_position = -1.0
        last_progress_at = time.time()
        while (not monitor.abortRequested()) and (not self.streamFinished):
            if self.isPlayingVideo():
                self._updateHlsBufferStatus()
                stopped_without_callback = 0
                try:
                    self.totalTime = self.getTotalTime()
                    self.currentTime = self.getTime()

                    # A user pause is not a stream stall. Reset the watchdog while paused.
                    if self._isPlaybackPaused():
                        last_progress_at = time.time()
                    elif self.currentTime > last_position + 0.25:
                        last_position = self.currentTime
                        last_progress_at = time.time()
                    elif time.time() - last_progress_at >= PLAYBACK_STALL_TIMEOUT:
                        self.playback_failed = True
                        self.streamFinished = True
                        log_utils.log('[xShip Playback] Playback stalled for %s seconds: %s' %
                                      (PLAYBACK_STALL_TIMEOUT, getattr(self, 'name', 'unbekannt')), log_utils.LOGWARNING)
                        self._closeStartupBusy()
                        self._stopFailedPlayback()
                        break

                    watcher = self.totalTime > 0 and (self.currentTime / self.totalTime >= .85)
                    if watcher and not self.watcher_control:
                        playcountDB.updatePlaycount(self.mediatype, self.title, self.name, self.imdb, self.number_of_seasons, self.season, self.number_of_episodes, self.episode, 1)
                        self.watcher_control = True
                except:
                    pass
            else:
                # Kodi normally calls onPlayBackStopped/Ended. If the callback is
                # lost, do not leave this Python invocation alive forever.
                stopped_without_callback += 1
                if stopped_without_callback >= 20:  # ~2 seconds
                    log_utils.log('[xShip Playback] Playback ended without callback', log_utils.LOGWARNING)
                    self.streamFinished = True
                    break
            monitor.waitForAbort(0.1)

        # Important: database/bookmark/navigation work is deliberately performed
        # here, on the plugin invocation thread, not inside Kodi's Player callback.
        self._finishPlaybackOutsideCallback()
        if self.isdebug: log_utils.log('Ende - keepPlaybackAlive', log_utils.LOGINFO)


    def _isPlaybackPaused(self):
        try:
            return bool(control.condVisibility('Player.Paused'))
        except:
            return False


    def _stopFailedPlayback(self):
        try:
            if self.isPlaying():
                self.stop()
        except:
            try:
                xbmc.Player().stop()
            except:
                pass


    def _finishPlaybackOutsideCallback(self):
        self._clearTraktIdentity()
        self._closeHlsPrebuffer()
        if self._playback_cleanup_done:
            return
        self._playback_cleanup_done = True
        self._closeStartupBusy()

        if not self.playback_started:
            return

        if self.isdebug: log_utils.log('[xShip Playback] deferred playback cleanup start', log_utils.LOGINFO)
        try:
            self.runVideoDB()
        except Exception as e:
            log_utils.log('[xShip Playback] runVideoDB cleanup error: %s' % str(e), log_utils.LOGWARNING)

        try:
            if self.watcher_control or self._playback_ended:
                bookmarks().remove(self.name)
                self.parentDir()
                self.watcher_control = False
            else:
                bookmarks().save(self.currentTime, self.name)
        except Exception as e:
            log_utils.log('[xShip Playback] bookmark/navigation cleanup error: %s' % str(e), log_utils.LOGWARNING)
        if self.isdebug: log_utils.log('[xShip Playback] deferred playback cleanup end', log_utils.LOGINFO)


    def idleForPlayback(self):
        for i in range(0, 200):
            if control.visible():
                control.idle()
            else:
                break
            xbmc.sleep(100)

    def onPlayBackStarted(self):
        if self.isdebug: log_utils.log('Start - onPlayBackStarted', log_utils.LOGINFO)
        # Opening a stream is not proof that audio/video actually started.
        # Only Kodi's onAVStarted confirms a successful playback handoff.

    def onAVStarted(self):
        if self._av_started:
            return
        if self.isdebug: log_utils.log('Start - onAVStarted', log_utils.LOGINFO)
        self.playback_started = True
        # Flag zuerst setzen: verhindert ein Reopen durch den Handoff-Code, falls
        # Callback und run() zeitlich direkt aufeinander treffen.
        self._av_started = True
        self._closeStartupBusy()
        control.execute('Dialog.Close(all,true)')
        if not self.offset == '0': self.seekTime(float(self.offset))
        self.idleForPlayback()
        if control.getSetting('subtitles') == 'true':
            status = subtitles().get(self.name, self.imdb, self.season, self.episode)
            ## Subtitles in Player Menü ausschalten - wird dann bei Bedarf per "Hand" eingeschaltet
            # xbmc.executeJSONRPC('{"jsonrpc": "2.0", "method": "Player.SetSubtitle", "params": {"playerid": 1, "subtitle" : "on"}, "id": "1"}')
            xbmc.executeJSONRPC('{"jsonrpc": "2.0", "method": "Player.SetSubtitle", "params": {"playerid": 1, "subtitle" : "off"}, "id": "1"}')
        if self.isdebug: log_utils.log('Ende - onAVStarted', log_utils.LOGINFO)


    def onPlayBackError(self):
        log_utils.log('[xShip Playback] onPlayBackError (AV started=%s)' % self._av_started, log_utils.LOGWARNING)
        self.playback_failed = True
        self._closeStartupBusy()
        self.streamFinished = True

    def onPlayBackStopped(self):
        # Keep Kodi's player callback lightweight. DB, bookmarks and navigation
        # are handled after keepPlaybackAlive() leaves its monitor loop.
        if self.isdebug: log_utils.log('[xShip Playback] onPlayBackStopped -> signal only', log_utils.LOGINFO)
        self._closeStartupBusy()
        self._playback_ended = False
        # Kodi can report a demux/open failure as Stopped without Error.
        # Before AV-start this is a failed attempt, not a completed playback.
        self.user_stopped = self._av_started and not self.playback_failed
        if not self._av_started:
            self.playback_failed = True
        log_utils.log('[xShip Playback] Stopped: AV started=%s, user stop=%s, failed=%s' %
                      (self._av_started, self.user_stopped, self.playback_failed), log_utils.LOGWARNING)
        self.streamFinished = True

    def onPlayBackEnded(self):
        if self.isdebug: log_utils.log('[xShip Playback] onPlayBackEnded -> signal only', log_utils.LOGINFO)
        self._closeStartupBusy()
        self._playback_ended = True
        self.streamFinished = True


    def parentDir(self):
        """Navigiert nach Filmende zurück zur Filmliste und aktualisiert Playcount-Anzeige.

        Im Verzeichnis-Modus (hosts.mode='1') erzeugt die Quellenauswahl eine extra
        Navigationsebene. Nach dem Abspielen steht der User in der Quellenliste
        (Container.Content='videos') und muss per ParentDir zurück zur Filmliste
        (Container.Content='movies') navigiert werden.
        """
        try:
            monitor = xbmc.Monitor()
            hosts_mode = control.getSetting('hosts.mode')
            # Verzeichnis-Modus: Quellenliste -> zurück zur Filmliste
            if hosts_mode == '1':
                if self.isdebug: log_utils.log(__name__ + ' - parentDir: start (hosts_mode=%s)' % hosts_mode, log_utils.LOGINFO)
                # Warte bis Kodi die Quellenliste wieder anzeigt (nach Player-Close)
                if not self._wait_for_content('videos', monitor, timeout=5.0):
                    if self.isdebug: log_utils.log(__name__ + ' - parentDir: Timeout waiting for videos', log_utils.LOGINFO)
                    return
                # Eine Ebene hoch: Quellenliste -> Filmliste
                if control.getInfoLabel("Container.Content") != 'movies':
                    control.execute('Action(ParentDir)')
                    if not self._wait_for_content('movies', monitor, timeout=3.0):
                        if self.isdebug: log_utils.log(__name__ + ' - parentDir: Timeout waiting for movies', log_utils.LOGINFO)
                        return

            # Playcount-Häkchen sichtbar machen (nur bei erstmaliger Wiedergabe)
            if self.playcount == 0 and hosts_mode == '2' and not xbmc.getCondVisibility('system.platform.windows'):
                control.execute('Container.Refresh')
            elif self.playcount == 0 and hosts_mode == '1':
                control.execute('Container.Refresh')
            if self.isdebug: log_utils.log(__name__ + ' - parentDir: done (hosts_mode=%s)' % hosts_mode, log_utils.LOGINFO)
        except Exception as e:
            log_utils.log(__name__ + ' - parentDir error: %s' % e, log_utils.LOGERROR)


    def _wait_for_content(self, target, monitor, timeout=3.0):
        """Pollt Container.Content bis Zielwert erreicht oder Timeout.
        100ms-Intervall: schnell genug für reaktive UI, schonend genug für CPU.
        """
        deadline = time.time() + timeout
        while time.time() < deadline:
            if monitor.abortRequested():
                return False
            if control.getInfoLabel("Container.Content") == target:
                return True
            monitor.waitForAbort(0.1)
        return False

# keine Einträge für bookmarks und files in die Kodi DB 'MyVideos116.db' anlegen bzw. sofort löschen
    def runVideoDB(self):
        idFile = self.getVideoDB()
        if idFile != self.fileID:
            self.removeVideoDB(idFile)

    def getVideoDB(self):
        dbcon = database.connect(self.videoDB)
        dbcur = dbcon.cursor()
        dbcur.execute("SELECT * FROM files")
        match = dbcur.fetchall()
        dbcon.close()
        if match and len(match) > 0: idFile = len(match)
        else: idFile = 0
        return idFile

    def removeVideoDB(self, idFile):
        dbcon = database.connect(self.videoDB)
        dbcur = dbcon.cursor()
        dbcur.execute("DELETE FROM files WHERE idFile = '%s'" % idFile) # in DB vorhandener Trigger löscht auch den bookmark
        dbcon.commit()
        dbcon.close()


class subtitles:
    def __init__(self, *args, **kwargs):
        from xbmcaddon import Addon
        __scriptname__ = "XBMC Subtitles Login"
        __version__ = Addon().getAddonInfo('version')  # Module version
        BASE_URL_XMLRPC = u"http://api.opensubtitles.org/xml-rpc"

        self.server = _xmlrpclib.ServerProxy(BASE_URL_XMLRPC, verbose=0)
        login = self.server.LogIn(Addon().getSetting('subtitles.os_user'), Addon().getSetting('subtitles.os_pass'), "en", "%s_v%s" % (__scriptname__.replace(" ", "_"), __version__))
        if login["status"] == "200 OK":
            self.osdb_token = login["token"]

    def get(self, name, imdb, season, episode):
        isdebug = True if control.getSetting('status.debug') == 'true' else False
        if isdebug: log_utils.log('Start - get subtitles', log_utils.LOGINFO)
        subtitlepath = control.translatePath('special://temp/temp/')
        if not os.path.exists(subtitlepath): os.mkdir(subtitlepath)

        # struktur = json.loads(xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Settings.GetSettingValue", "params":{"setting":"subtitles.custompath"},"id":1}'))
        # if struktur["result"]["value"] != subtitlepath:
        #     xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Settings.setSettingValue","id":1,"params":{"setting":"subtitles.custompath", "value": "%s"}}' % subtitlepath.replace('\\', '\\\\'))

        controlfile = control.translatePath('special://temp/temp/%s' % name.replace(' ','-'))+'.ifo'
        if not os.path.exists(controlfile):
            for f in os.listdir(subtitlepath):
                os.remove(os.path.join(subtitlepath, f))
            with open(controlfile, mode='a'):
                pass

        season = str(season)
        episode = str(episode)
        # import pydevd
        # pydevd.settrace('localhost', port=12345, stdoutToServer=True, stderrToServer=True)
        try:
            langDict = {'Afrikaans': 'afr', 'Albanian': 'alb', 'Arabic': 'ara', 'Armenian': 'arm', 'Basque': 'baq', 'Bengali': 'ben', 'Bosnian': 'bos', 'Breton': 'bre', 'Bulgarian': 'bul', 'Burmese': 'bur', 'Catalan': 'cat', 'Chinese': 'chi', 'Croatian': 'hrv', 'Czech': 'cze', 'Danish': 'dan', 'Dutch': 'dut', 'English': 'eng', 'Esperanto': 'epo', 'Estonian': 'est', 'Finnish': 'fin', 'French': 'fre', 'Galician': 'glg', 'Georgian': 'geo', 'German': 'ger', 'Greek': 'ell', 'Hebrew': 'heb', 'Hindi': 'hin', 'Hungarian': 'hun', 'Icelandic': 'ice', 'Indonesian': 'ind', 'Italian': 'ita', 'Japanese': 'jpn', 'Kazakh': 'kaz', 'Khmer': 'khm', 'Korean': 'kor', 'Latvian': 'lav', 'Lithuanian': 'lit', 'Luxembourgish': 'ltz', 'Macedonian': 'mac', 'Malay': 'may', 'Malayalam': 'mal', 'Manipuri': 'mni', 'Mongolian': 'mon', 'Montenegrin': 'mne', 'Norwegian': 'nor', 'Occitan': 'oci', 'Persian': 'per', 'Polish': 'pol', 'Portuguese': 'por,pob', 'Portuguese(Brazil)': 'pob,por', 'Romanian': 'rum', 'Russian': 'rus', 'Serbian': 'scc', 'Sinhalese': 'sin', 'Slovak': 'slo', 'Slovenian': 'slv', 'Spanish': 'spa', 'Swahili': 'swa', 'Swedish': 'swe', 'Syriac': 'syr', 'Tagalog': 'tgl', 'Tamil': 'tam', 'Telugu': 'tel', 'Thai': 'tha', 'Turkish': 'tur', 'Ukrainian': 'ukr', 'Urdu': 'urd'}
            codePageDict = {'ara': 'cp1256', 'ar': 'cp1256', 'ell': 'cp1253', 'el': 'cp1253', 'heb': 'cp1255', 'he': 'cp1255', 'tur': 'cp1254', 'tr': 'cp1254', 'rus': 'cp1251', 'ru': 'cp1251'}

            langs = []
            try:
                try: langs = langDict[control.getSetting('subtitles.lang.1')].split(',')
                except: langs.append(langDict[control.getSetting('subtitles.lang.1')])
            except:
                langs = ['ger']
            ## Einstellungen/Player/Sprache
            # bevorzugte Audiosprache - Sprache der Benutzeroberfläche
            xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Settings.setSettingValue", "params":{"setting":"locale.audiolanguage", "value": "default"},"id":1}')
            # bevorzugte Untertitelsprache - Sprache der Benutzeroberfläche
            xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Settings.setSettingValue", "params":{"setting":"locale.subtitlelanguage", "value": "default"},"id":1}')
            ## Einstellungen/Player/Untertitel
            xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Settings.setSettingValue", "params":{"setting":"subtitles.languages", "value": ["%s"]},"id":1}' % (control.getSetting('subtitles.lang.1')))

            try: subLang = xbmc.Player().getSubtitles()
            except: subLang = ''
            if subLang == langs[0]: raise Exception()

            imdbid = re.sub(r'[^0-9]', '', imdb)
            if season == 'None' or episode == 'None':
                result = self.server.SearchSubtitles(self.osdb_token, [{'sublanguageid': langs[0], 'imdbid': imdbid}])['data']
            else:
                result = self.server.SearchSubtitles(self.osdb_token, [{'sublanguageid': langs[0], 'imdbid': imdbid, 'season': season, 'episode': episode}])['data']
            if result == []: raise Exception()

            if langs == ['ger']: # alles nur deutsch
                result = [i for i in result if i['SubSumCD'] == '1' and i['LanguageName'] == 'German' and i['ISO639'] == 'de' and i['SubLanguageID'] == 'ger']
            else:
                result = [i for i in result if i['SubSumCD'] == '1']

            result=sorted(result, key=lambda k: int(k['SubSize']), reverse=True)

            # filter = []
            # for userrank in ['OS Legend','Administrator','Translator','Platinum member','Gold member','Silver member', 'Bronze member','trusted','']:
            #     for i in result:
            #         if i['UserRank'] == userrank.lower():
            #             filter.append(i)

            count = 0
            for i in result:
                try: lang = xbmc.convertLanguage(i['SubLanguageID'], xbmc.ISO_639_1)
                except: lang = i['SubLanguageID']
                subtitle = os.path.join(subtitlepath, i['SubFileName'])
                if not os.path.exists(subtitle):
                    ZipDownloadID = i['ZipDownloadLink'].split('/')[-1]
                    ZipDownloadLink = 'https://dl.opensubtitles.org/en/download/sub/%s' % ZipDownloadID

                    import requests, zipfile
                    r = requests.get(ZipDownloadLink, timeout=(3, 5))
                    status = r.status_code
                    if status == 200:
                        zf = zipfile.ZipFile(_io(r.content))
                        content = ''
                        for name in zf.namelist():
                            if not name.endswith('.srt'): continue
                            content = zf.read(name)

                        codepage = codePageDict.get(lang, '')
                        if codepage and control.getSetting('subtitles.utf') == 'true':
                            try:
                                content_encoded = codecs.decode(content, codepage)
                                content = codecs.encode(content_encoded, 'utf-8')
                            except:
                                pass

                        output = open(subtitle, 'wb')
                        output.write(content)
                        output.close()
                    else:
                        if count == 0:
                            from xbmcvfs import copy
                            errorfile = translatePath('special://home/addons/plugin.video.xship/resources/error.connect.opensubtitles.org.srt')
                            subtitle = subtitlepath + 'error.connect.opensubtitles.org.srt'
                            copy(errorfile, subtitle)
                            xbmc.Player().setSubtitles(subtitle)
                            return False
                        else: break
                xbmc.Player().setSubtitles(subtitle)
                count += 1
                if count == 3: break

            return True
        except:
            return False



class bookmarks:
    def get(self, name):
        from resources.lib import bookmarkDB
        offset = '0'
        try:
            # if not control.getSetting('bookmarks') == 'true': raise Exception()
            idFile = hashlib.md5()
            for i in name:
                try:
                    idFile.update(str(i).encode('utf-8'))
                except:
                    idFile.update(str(i))
            idFile = str(idFile.hexdigest())

            match = bookmarkDB.get_query(idFile, 'bookmarks.pcl')
            if match:
                self.offset = str(match[1])
                if self.offset == '0': raise Exception()
                minutes, seconds = divmod(float(self.offset), 60)
                hours, minutes = divmod(minutes, 60)
                label = '%02d:%02d:%02d' % (hours, minutes, seconds)
                label = control.py2_encode("Fortsetzen ab : %s" % label)
                if control.getSetting('bookmarks.auto') == 'false':
                    try:
                        yes = control.dialog.contextmenu([label, "Vom Anfang abspielen", ])
                    except:
                        yes = control.yesnoDialog(label, '', '', str(name), "Fortsetzen",
                                                  "Vom Anfang abspielen")
                    if yes:
                        bookmarkDB.remove_query(idFile, 'bookmarks')
                        self.offset = '0'
                return self.offset
            else:
                return offset
        except Exception as e:
            return offset


    def remove(self, name):
        from resources.lib import bookmarkDB
        try:
            idFile = hashlib.md5()
            for i in name:
                try:
                    idFile.update(str(i).encode('utf-8'))
                except:
                    idFile.update(str(i))
            idFile = str(idFile.hexdigest())
            # if (currentTime / totalTime) >= .87:
            bookmarkDB.remove_query(idFile, 'bookmarks')
        except:
            pass

    def save(self, currentTime, name):
        from resources.lib import bookmarkDB
        try:
            if int(currentTime) > 180:
                timeInSeconds = str(currentTime)
                idFile = hashlib.md5()
                for i in name:
                    try:
                        idFile.update(str(i).encode('utf-8'))
                    except:
                        idFile.update(str(i))
                idFile = str(idFile.hexdigest())
                bookmarkDB.save_query(idFile, timeInSeconds, 'bookmarks')
        except:
            pass

