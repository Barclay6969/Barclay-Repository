
# 2022-10-09
# edit 2026.06.19

import sys, re, datetime, os
import requests
from random import choice
from xbmcaddon import Addon
from xbmcvfs import translatePath
from urllib.parse import urlparse
try:
    from resources.lib.tools import logger
    isLogger=True
except:
    isLogger=False
    pass


addonInfo = Addon().getAddonInfo
addonPath = translatePath(addonInfo('path'))
addonVersion = addonInfo('version')
setSetting = Addon().setSetting
_getSetting = Addon().getSetting

# ResolveURL Auto-Update
RESOLVE_ADDON_DATA_PATH = translatePath(os.path.join('special://home/userdata/addon_data/script.module.resolveurl'))
RESOLVE_SHA = os.path.join(RESOLVE_ADDON_DATA_PATH, "update_sha")

def getSetting(Name, default=''):
    result = _getSetting(Name)
    if result: return result
    else: return default

# Html Cache beim KodiStart loeschen
def delHtmlCache():
    try:
        from resources.lib.requestHandler import cRequestHandler
        from time import time
        deltaDay = int(getSetting('cacheDeltaDay', '7'))
        deltaTime = 60*60*24*deltaDay # Tage
        currentTime = int(time())
        # einmalig
        if getSetting('delHtmlCache') == 'true':
            cRequestHandler('').clearCache()
            setSetting('lastdelhtml', str(currentTime))
            setSetting('delHtmlCache', 'false')
        # alle x Tage
        elif currentTime >= int(getSetting('lastdelhtml', '0')) + deltaTime:
            cRequestHandler('').clearCache()
            setSetting('lastdelhtml', str(currentTime))
    except:
        pass

# Scraper(Seiten) ein- / ausschalten
#  [(providername, domainname), ...]     providername identisch mit dateiname
def _getPluginData():
    from os import path, listdir
    sPluginFolder = path.join(addonPath, 'scrapers', 'scrapers_source', 'de')
    if sPluginFolder not in sys.path:
        sys.path.append(sPluginFolder)
    items = listdir(sPluginFolder)
    aFileNames=[]
    aPluginsData = []
    for sItemName in items:
        if sItemName.endswith('.py'): aFileNames.append(sItemName[:-3])
    for fileName in aFileNames:
        if fileName ==  '__init__': continue
        try:
            plugin = __import__(fileName, globals(), locals())
            aPluginsData.append({'domain': plugin.SITE_DOMAIN, 'provider': plugin.SITE_IDENTIFIER})
        except:
            pass
        finally:
            # Modul sofort entladen -- nur domain/provider werden gebraucht
            sys.modules.pop(fileName, None)
    # Scraper-Pfad entfernen (nicht dauerhaft in sys.path)
    try:
        sys.path.remove(sPluginFolder)
    except ValueError:
        pass
    return aPluginsData


def repair_blocked_provider_domains():
    """Repariert alte, bereits gespeicherte ISP-/CUII-Domainwerte sofort beim Start.

    Der normale Domain-Check hat ein 90-Minuten-Intervall. Deshalb konnten alte
    vodafone.de-Werte nach einem Addon-Update sichtbar bleiben. Diese Migration
    laeuft bewusst unabhaengig davon bei jedem Service-Start.
    """
    try:
        wrong = {
            'vodafone.de', 'www.vodafone.de', 'notice.cuii.info',
            'site-maps.cc', 'drei.at', 'www.drei.at', 'streamingunity.biz'
        }
        for item in _getPluginData():
            provider = item.get('provider', '')
            source_domain = (item.get('domain', '') or '').strip().lower()
            if not provider or not source_domain or source_domain in wrong:
                continue
            key = 'provider.' + provider + '.domain'
            current = (getSetting(key, '') or '').strip().lower()
            if current in wrong:
                setSetting(key, source_domain)
                if isLogger:
                    logger.info(' -> [service]: reparierte Provider-Domain %s: %s -> %s' % (provider, current, source_domain))
    except Exception:
        pass


def check_domains():
    """Prueft alle Provider-Domains parallel per HTTP HEAD.
    Ergebnisse werden in Kodi-Settings geschrieben
    (domain_status: 'ok', 'cf_blocked', 'dead')."""
    import time
    CHECK_INTERVAL = 60 * 90  # 90 Minuten in Sekunden
    currentTime = int(time.time())
    lastCheck = int(getSetting('lastDomainCheck', 0))
    if currentTime >= lastCheck + CHECK_INTERVAL:
        setSetting('lastDomainCheck', str(currentTime))
        domains = _getPluginData()
        import threading
        threads = []
        try:
            for item in domains:
                _domain = item['domain']
                _provider = item['provider']
                t = threading.Thread(target=_checkdomain, args=(_domain, _provider))
                threads += [t]
                t.start()
        except:
            pass
        for count, t in enumerate(threads):
            t.join(timeout=10)

def RandomUA():
    #Random User Agents aktualisiert 20.03.2026
    FF_USER_AGENT = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:148.0) Gecko/20100101 Firefox/148.0'
    OPERA_USER_AGENT = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36 OPR/129.0.0.0'
    ANDROID_USER_AGENT = 'Mozilla/5.0 (Linux; Android 15; SM-S938U Build/AP3A.241005.015; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/146.0.0.0 Mobile Safari/537.36'
    EDGE_USER_AGENT = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36 Edg/145.0.0.0'
    CHROME_USER_AGENT = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36'
    SAFARI_USER_AGENT = 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/26.0 Safari/605.1.15'

    _User_Agents = [FF_USER_AGENT, OPERA_USER_AGENT, EDGE_USER_AGENT, CHROME_USER_AGENT, SAFARI_USER_AGENT]
    return choice(_User_Agents)


def _checkdomain(_domain, _provider):
    """Prueft die konfigurierte Provider-Domain, ohne Redirect-Ziele als neue Domain zu speichern.

    Wichtig: ISP-/CUII-Sperrseiten wie vodafone.de duerfen niemals die manuell
    konfigurierte Provider-Domain ueberschreiben. Die Domain bleibt benutzerdefiniert;
    nur leere oder bekannte Fehlwerte werden auf SITE_DOMAIN des Scrapers zurueckgesetzt.
    """
    try:
        sourcefile = translatePath('special://home/addons/plugin.video.xship/scrapers/scrapers_source/de/%s.py' % _provider)
        pattern = r"SITE_DOMAIN.*?'([^']+)"
        with open(sourcefile, 'r') as f:
            contents = f.read()
        match = re.search(pattern, contents)
        source_domain = match.group(1) if match else _domain

        requests.packages.urllib3.disable_warnings()
        wrongDomain = ('site-maps.cc', 'drei.at', 'www.drei.at', 'notice.cuii.info',
                       'streamingunity.biz', 'vodafone.de', 'www.vodafone.de')
        wrong = set(x.lower() for x in wrongDomain)

        configured = getSetting('provider.' + _provider + '.domain', _domain)
        domain = (configured or '').strip().lower()
        if not domain or domain in wrong:
            domain = (source_domain or _domain or '').strip().lower()
            if domain and domain not in wrong:
                setSetting('provider.' + _provider + '.domain', domain)

        status_code = None
        health_status = 'unknown'
        if not domain or domain in wrong:
            setSetting('provider.' + _provider + '.health', 'dead')
            return

        base_link = 'http://' + domain
        try:
            UA = RandomUA()
            headers = {"referer": base_link, "user-agent": UA}
            r = requests.head(base_link, verify=False, headers=headers,
                              allow_redirects=True, timeout=2)
            status_code = r.status_code
            final_host = (urlparse(r.url).hostname or '').lower()

            # Redirect auf bekannte ISP-/Sperrseite: als blockiert/dead markieren,
            # aber NIEMALS die konfigurierte Domain veraendern.
            if final_host in wrong:
                health_status = 'dead'
            elif status_code == 200:
                health_status = 'ok'
            elif status_code in (403, 503, 520):
                health_status = 'cf_blocked'
            else:
                health_status = 'dead'
        except:
            health_status = 'dead'
        finally:
            # Die gespeicherte Domain bleibt immer die vom Benutzer konfigurierte
            # bzw. die im Scraper hinterlegte Originaldomain.
            if domain and domain not in wrong:
                setSetting('provider.' + _provider + '.domain', domain)
            setSetting('provider.' + _provider + '.health', health_status)
            if isLogger:
                logger.info(' -> [service]: Provider: %s / Statuscode: %s / Domain: %s, Health: %s' % (_provider, status_code, domain, health_status))
    except:
        pass


# Download Media Files
def downloadMedia():
    from os import path
    from xbmcvfs import delete
    from resources.lib.utils import download_url, unzip
    dest = translatePath(path.join(addonPath, 'resources'))
    contr = translatePath(path.join(addonPath, 'resources', 'media', 'next.png'))
    if not path.exists(contr):
        url = 'https://raw.githubusercontent.com/xsupdater/xsupdater/backup/media.zip'
        src = translatePath(path.join('special://temp', url.split('/')[-1]))
        download_url(url, src)
        src = translatePath(path.join('special://temp', url.split('/')[-1]))
        dirs = 'media'
        unzip(src, dest, folder=None)
        delete(src)


def ensure_youtube_api_keys():
    """Write bundled YouTube API keys to api_keys.json if not already configured.
    Only writes if no user key exists — never overwrites an existing configured key."""
    import json, base64, os
    try:
        yt_keys_path = translatePath('special://home/userdata/addon_data/plugin.video.youtube/api_keys.json')

        # If file exists, check whether a user key is already present
        if os.path.exists(yt_keys_path):
            try:
                with open(yt_keys_path, 'r') as f:
                    existing = json.load(f)
                if existing.get('keys', {}).get('user', {}).get('api_key', ''):
                    return  # user key already configured — do not touch
            except Exception:
                pass  # unreadable — fall through and write fresh

        # Write bundled fallback keys to api_keys.json.
        # JSON structure is visible as-is; values prefixed 'b64:' are decoded before writing.
        _template = """{
    "keys": {
        "user": {
            "api_key":       "b64:QUl6YVN5RG5sSjBlX0NabExvWm03Q01Obk80MXhJblpnVkZ5T2Jv",
            "client_id":     "b64:ODY5OTIyMDgxNzY5LWQzOTJkdTN2dTZjOGNwbXRsbDExcnBkN2YwOWRldTFuLmFwcHMuZ29vZ2xldXNlcmNvbnRlbnQuY29t",
            "client_secret": "b64:R09DU1BYLVpPSWYwSnM3cUFCN3FsTWNvRkFDTlpqVWhfQ2o="
        },
        "developer": {}
    }
}"""

        def _resolve(obj):
            if isinstance(obj, dict):
                return {k: _resolve(v) for k, v in obj.items()}
            if isinstance(obj, str) and obj.startswith('b64:'):
                return base64.b64decode(obj[4:].encode()).decode()
            return obj

        yt_dir = os.path.dirname(yt_keys_path)
        if not os.path.exists(yt_dir):
            os.makedirs(yt_dir)

        with open(yt_keys_path, 'w') as f:
            json.dump(_resolve(json.loads(_template)), f, indent=4)
        if isLogger:
            logger.info('[service]: YouTube api_keys.json written')
    except Exception as e:
        if isLogger:
            logger.warning('[service]: Failed to write YouTube api_keys.json: %s' % str(e))


def _resolverUpdateAuto():
    """Resolver Update im Hintergrund beim Kodi-Start.

    Logik:
    - xStream installiert+aktiv?  → skip (xStream uebernimmt das Update)
    - sonst                       → Update + Notifications (erfolgreich/Fehler/kein Update)
    """
    try:
        # xStream aktiv → der uebernimmt das Update, xShip haelt sich raus
        import xbmc
        if xbmc.getCondVisibility('System.AddonIsEnabled(plugin.video.xstream)'):
            if isLogger:
                logger.info('[service]: xStream active — skipping resolver update (xStream handles it)')
            return

        # xShip uebernimmt das Update
        if not os.path.isfile(RESOLVE_SHA) or getSetting('githubUpdateResolver') == 'true':
            from resources.lib import updateManager
            from resources.lib.control import infoDialog
            status = updateManager.resolverUpdate()
            if status is True:
                infoDialog('ResolveURL Update erfolgreich.', icon='INFO', time=6000)
            elif status is False:
                infoDialog('Fehler bei ResolveURL Update.', icon='ERROR', sound=True)
            # status is None = kein Update verfuegbar → beim Auto-Update keine Notify (nur Noise beim Start)
    except Exception:
        if isLogger:
            import traceback
            logger.error('[service]: Resolver update error: %s' % traceback.format_exc())


if __name__ == "__main__":
    import xbmc
    monitor = xbmc.Monitor()

    # InputStream Adaptive beim Start sicherstellen (wie 0.9er): fehlt es, nachinstallieren
    # und den Bestaetigungsdialog automatisch wegklicken. Beim Abspielen ist ISA dann da.
    from xbmc import getCondVisibility, executebuiltin
    if not getCondVisibility("System.HasAddon(inputstream.adaptive)"):
        executebuiltin('InstallAddon(inputstream.adaptive)')
        executebuiltin('SendClick(11)')

    # Alte ISP-/CUII-Fehlwerte sofort reparieren (unabhaengig vom 90-Minuten-Intervall)
    repair_blocked_provider_domains()

    # ResolveURL-Update + Domain-Check parallel
    from concurrent.futures import ThreadPoolExecutor
    with ThreadPoolExecutor(max_workers=1) as executor:
        # Resolver-Update im Hintergrund (skippt wenn xStream aktiv, sonst mit Notifys)
        resolver_future = executor.submit(_resolverUpdateAuto)
        # Domain-Check parallel im Main-Thread
        check_domains()
        delHtmlCache()
        # Auf Resolver warten (max 13s: Commits-API 4s + ZIP-Download 8s + 1s Puffer)
        try:
            resolver_future.result(timeout=13)
        except Exception:
            if isLogger:
                logger.debug('[service]: Resolver update timed out or failed, continuing')

    # # Precache-Monitoring: alle 10s pruefen ob xShip aktiv + Precache noetig
    # # Thread laeuft hier im service.py-Invoker (persistent) — blockiert nichts
    # while not monitor.waitForAbort(10):
    #     try:
    #         from resources.lib.precacher import start_if_needed
    #         start_if_needed()
    #     except:
    #         pass

