# MOFLIX TEST14 TMDB DIRECT VIA IMDB FALLBACK
# MOFLIX TEST13 TMDB DIRECT
# MOFLIX TEST12 DIAG-MATCH TRANSPORT
# MOFLIX TEST11 REQUESTS TRANSPORT
# -*- coding: UTF-8 -*-

import base64
import json
import re
import time
from html import unescape as html_unescape
from urllib.parse import quote_plus, urljoin, urlparse, unquote

import requests as _moflix_requests

# Test11 helper: Laravel XSRF cookie decoding
from urllib.parse import unquote as _moflix_unquote
from resources.lib.requestHandler import cRequestHandler
from scrapers.modules import cleantitle
from resources.lib.control import getSetting, quote
from resources.lib.utils import isBlockedHoster
from resources.lib import log_utils


# MOFLIX TEST12 DIAG-MATCH SESSION
class _MoflixTest12Session(_moflix_requests.Session):
    _ua = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36"
    _accept_lang = "de-DE,de;q=0.9,en-US;q=0.8,en;q=0.7"

    def __init__(self):
        super().__init__()
        self.headers.update({
            "User-Agent": self._ua,
            "Accept-Language": self._accept_lang,
        })

    def request(self, method, url, **kwargs):
        try:
            from urllib.parse import unquote, urlparse
            parsed = urlparse(str(url or ""))
            host = (parsed.hostname or "").lower()

            if host == "moflix-stream.xyz" or host.endswith(".moflix-stream.xyz"):
                supplied = kwargs.pop("headers", None) or {}

                if parsed.path in ("", "/"):
                    # Exactly the successful diagnostic bootstrap shape.
                    h = {
                        "User-Agent": self._ua,
                        "Accept-Language": self._accept_lang,
                    }
                    for k, v in supplied.items():
                        if str(k).lower() in ("authorization", "cookie"):
                            h[k] = v
                    kwargs["headers"] = h

                elif "/api/" in parsed.path:
                    referer = "https://moflix-stream.xyz/"
                    m = re.search(r"/api/v1/search/([^/?]+)", parsed.path, re.I)
                    if m:
                        referer = "https://moflix-stream.xyz/search/" + m.group(1)

                    h = {
                        "User-Agent": self._ua,
                        "Accept": "application/json",
                        "Accept-Language": self._accept_lang,
                        "Referer": referer,
                        "sec-ch-ua": '"Not=A?Brand";v="99", "Google Chrome";v="151", "Chromium";v="151"',
                        "sec-ch-ua-mobile": "?0",
                        "sec-ch-ua-platform": '"Windows"',
                        "sec-fetch-dest": "empty",
                        "sec-fetch-mode": "cors",
                        "sec-fetch-site": "same-origin",
                    }
                    try:
                        xsrf = self.cookies.get("XSRF-TOKEN")
                    except Exception:
                        xsrf = None
                    if xsrf:
                        h["X-XSRF-TOKEN"] = unquote(xsrf)

                    for k, v in supplied.items():
                        if str(k).lower() == "authorization":
                            h[k] = v
                    kwargs["headers"] = h

                else:
                    kwargs["headers"] = {
                        "User-Agent": self._ua,
                        "Accept": "text/html,application/xhtml+xml",
                        "Accept-Language": self._accept_lang,
                    }

                try:
                    log_utils.log(
                        "[MOFLIX-TEST12] %s %s cookies=%s xsrf=%s" % (
                            str(method).upper(),
                            parsed.path or "/",
                            len(self.cookies),
                            "yes" if self.cookies.get("XSRF-TOKEN") else "no"
                        ),
                        log_utils.LOGINFO
                    )
                except Exception:
                    pass
        except Exception as exc:
            try:
                log_utils.log("[MOFLIX-TEST12] header setup warning: %s" % exc, log_utils.LOGINFO)
            except Exception:
                pass

        response = super().request(method, url, **kwargs)

        try:
            from urllib.parse import urlparse
            if "moflix-stream.xyz" in str(url):
                log_utils.log(
                    "[MOFLIX-TEST12] response status=%s path=%s cookies=%s xsrf=%s session=%s" % (
                        getattr(response, "status_code", "?"),
                        urlparse(str(url)).path,
                        len(self.cookies),
                        "yes" if self.cookies.get("XSRF-TOKEN") else "no",
                        "yes" if self.cookies.get("moflix_stream_session") else "no",
                    ),
                    log_utils.LOGINFO
                )
        except Exception:
            pass
        return response
# END MOFLIX TEST12 DIAG-MATCH SESSION


SITE_IDENTIFIER = 'moflix'
SITE_DOMAIN = 'moflix-stream.xyz'
SITE_NAME = SITE_IDENTIFIER.upper()
UA = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36'


class source:
    def __init__(self):
        self.priority = getSetting('provider.' + SITE_IDENTIFIER + '.priority', 100)
        self.language = ['de']
        self.domain = getSetting('provider.' + SITE_IDENTIFIER + '.domain', SITE_DOMAIN)
        self.base_link = 'https://' + self.domain.strip('/')
        # Current Moflix API flow captured in browser HAR on 2026-09-30.
        self.search_link = self.base_link + '/api/v1/search/%s?loader=searchPage'
        self.detail_link = self.base_link + '/api/v1/titles/%s?loader=titlePage'
        self.season_link = self.base_link + '/api/v1/titles/%s/seasons/%s?loader=seasonPage&perPage=100'
        self.watch_link = self.base_link + '/api/v1/watch/%s'
        self.sources = []
        self._seen = set()
        self._xsrf_token = ''
        self._cookie_header = ''
        self._session_bootstrap_at = 0
        self._cf_scraper = None
        self._cf_bootstrap_done = False

    def run(self, titles, year, season=0, episode=0, imdb='', hostDict=None):
        try:
            # TEST13: Moflix supports a deterministic TMDb title identifier.
            # xShip already receives tmdb_id from TMDb Helper, so try this
            # public title endpoint first and avoid the CF-protected text search.
            item = self._direct_tmdb_match(season, imdb)
            if not item:
                log_utils.log('[MOFLIX-TMDB-DIRECT] unavailable; fallback to text search', log_utils.LOGINFO)
                item = self._best_match(titles, year, season, imdb)
            if not item:
                log_utils.log('[MOFLIX-XVAULT] no matching title found', log_utils.LOGINFO)
                return self.sources

            if int(season or 0) > 0 and int(episode or 0) > 0:
                videos = self._episode_videos(item.get('id'), season, episode)
            else:
                # _direct_tmdb_match already returns the normal Moflix title
                # object. Reuse its videos when present; otherwise load by
                # numeric Moflix id as before.
                videos = item.get('videos') or []
                if not videos:
                    detail = self._json(self.detail_link % item.get('id'), self._title_referer(item), 'titlePage')
                    title_data = detail.get('title') if isinstance(detail.get('title'), dict) else {}
                    videos = title_data.get('videos') or []

            self._add_videos(videos)
        except Exception as exc:
            log_utils.log('[MOFLIX-XVAULT] error: %s' % exc, log_utils.LOGERROR)
        return self.sources

    def _tmdb_from_imdb(self, imdb):
        """Resolve TMDb id from IMDb using the same cached TMDb lookup xShip already uses for VixStream."""
        try:
            imdb = str(imdb or '').strip()
            if not imdb or imdb.lower() in ('none', 'null', 'unknown'):
                return ''
            api_key = getSetting('api.tmdb') or base64.b64decode(
                'ZWRkZTZiNWU0MTI0NmFiNzlhMjY5N2NkMTI1ZTE3ODE='
            ).decode('ascii')
            url = 'https://api.themoviedb.org/3/find/%s?api_key=%s&external_source=imdb_id' % (imdb, api_key)
            req = cRequestHandler(url, caching=True, ignoreErrors=True)
            payload = req.request()
            data = json.loads(payload or '{}')
            if data.get('movie_results'):
                return str(data['movie_results'][0].get('id') or '')
            if data.get('tv_results'):
                return str(data['tv_results'][0].get('id') or '')
        except Exception as exc:
            log_utils.log('[MOFLIX-TMDB-DIRECT] imdb->tmdb error=%s' % exc, log_utils.LOGINFO)
        return ''

    def _direct_tmdb_match(self, season=0, imdb=''):
        """Resolve the Moflix title directly from xShip's TMDb id.

        Current Moflix clients use base64('tmdb|movie|ID') or
        base64('tmdb|series|ID') as the title identifier. This avoids the
        /api/v1/search endpoint, which Cloudflare currently challenges for
        non-browser clients.
        """
        try:
            tmdb_id = str(getattr(self, 'tmdb_id', '') or '').strip()
            if tmdb_id.lower() in ('', 'none', 'null', 'unknown'):
                tmdb_id = self._tmdb_from_imdb(imdb)
                if tmdb_id:
                    log_utils.log('[MOFLIX-TMDB-DIRECT] tmdb resolved from imdb=%s -> %s' % (imdb, tmdb_id), log_utils.LOGINFO)
                else:
                    log_utils.log('[MOFLIX-TMDB-DIRECT] no tmdb_id and imdb lookup failed', log_utils.LOGINFO)
                    return None

            # Keep only the numeric TMDb id if an external player supplied it
            # as a string with incidental whitespace.
            if not tmdb_id.isdigit():
                match = re.search(r'\d+', tmdb_id)
                if not match:
                    log_utils.log('[MOFLIX-TMDB-DIRECT] invalid tmdb_id=%s' % tmdb_id, log_utils.LOGINFO)
                    return None
                tmdb_id = match.group(0)

            media_kind = 'series' if int(season or 0) > 0 else 'movie'
            raw_id = 'tmdb|%s|%s' % (media_kind, tmdb_id)
            encoded_id = base64.b64encode(raw_id.encode('utf-8')).decode('ascii')
            direct_url = self.detail_link % encoded_id

            log_utils.log('[MOFLIX-TMDB-DIRECT] try kind=%s tmdb=%s' % (media_kind, tmdb_id), log_utils.LOGINFO)
            data = self._json(direct_url, self.base_link + '/', 'tmdbTitlePage')
            title_data = data.get('title') if isinstance(data, dict) and isinstance(data.get('title'), dict) else {}
            if not title_data or not title_data.get('id'):
                log_utils.log('[MOFLIX-TMDB-DIRECT] no title for tmdb=%s' % tmdb_id, log_utils.LOGINFO)
                return None

            log_utils.log('[MOFLIX-TMDB-DIRECT] OK tmdb=%s moflix_id=%s name=%s' % (
                tmdb_id, title_data.get('id'), title_data.get('name') or title_data.get('title') or ''
            ), log_utils.LOGINFO)
            return title_data
        except Exception as exc:
            log_utils.log('[MOFLIX-TMDB-DIRECT] error=%s' % exc, log_utils.LOGINFO)
            return None

    def resolve(self, url):
        return url

    def _best_match(self, titles, year, season, imdb):
        candidates = []
        seen = set()
        is_movie = int(season or 0) == 0
        search_titles = self._movie_search_titles(titles) if is_movie else self._search_titles(titles)

        log_utils.log('[MOFLIX-HAR] search start titles=%s year=%s season=%s imdb=%s' % (
            titles, year, season, imdb
        ), log_utils.LOGINFO)

        for title in search_titles:
            path_title = quote(title)
            search_url = self.search_link % path_title
            search_referer = self.base_link + '/search/' + path_title
            data = self._json(search_url, search_referer, 'searchPage')
            results = data.get('results') if isinstance(data, dict) else []

            log_utils.log('[MOFLIX-HAR] query=%s results=%s' % (title, len(results or [])), log_utils.LOGINFO)

            for item in results or []:
                if not isinstance(item, dict):
                    continue
                if str(item.get('model_type') or '').lower() == 'person':
                    continue
                item_id = item.get('id')
                if not item_id or item_id in seen:
                    continue
                seen.add(item_id)

                if is_movie:
                    score, reason = self._movie_match_score(item, titles, year, imdb)
                    log_utils.log('[MOFLIX-HAR] candidate id=%s name=%s year=%s imdb=%s series=%s score=%s reason=%s' % (
                        item_id,
                        item.get('name') or item.get('title') or item.get('original_title') or '',
                        self._year(item),
                        item.get('imdb_id') or '',
                        item.get('is_series'),
                        score,
                        reason
                    ), log_utils.LOGINFO)
                else:
                    score = self._match_score(item, titles, year, season, imdb)

                if score > 0:
                    candidates.append((score, item))

        candidates.sort(key=lambda value: value[0], reverse=True)
        if candidates:
            best_score, best_item = candidates[0]
            log_utils.log('[MOFLIX-HAR] match score=%s id=%s name=%s' % (
                best_score, best_item.get('id'), best_item.get('name') or best_item.get('title') or ''
            ), log_utils.LOGINFO)
            return best_item

        log_utils.log('[MOFLIX-HAR] no match', log_utils.LOGINFO)
        return None

    def _match_score(self, item, titles, year, season, imdb):
        want_series = int(season or 0) > 0
        is_series = bool(item.get('is_series'))
        if want_series != is_series:
            return 0

        score = 0
        if imdb and str(item.get('imdb_id') or '').strip().lower() == str(imdb).strip().lower():
            score += 100

        clean_titles = set(cleantitle.get(title) for title in titles or [] if title)
        item_titles = set()
        for key in ['name', 'title', 'original_title']:
            value = item.get(key)
            if value:
                item_titles.add(cleantitle.get(value))
        for value in list(item_titles):
            stripped = re.sub(r'(unrated|extended|directorscut|germansub|uncut)$', '', value or '')
            if stripped:
                item_titles.add(stripped)

        if clean_titles.intersection(item_titles):
            score += 60
        elif self._loose_title_match(clean_titles, item_titles):
            score += 25
        elif not score:
            return 0

        item_year = self._year(item)
        try:
            if year and item_year:
                delta = abs(int(year) - int(item_year))
                if delta == 0:
                    score += 20
                elif delta == 1:
                    score += 8
                else:
                    score -= 35
        except Exception:
            pass
        return score

    def _movie_match_score(self, item, titles, year, imdb):
        if bool(item.get('is_series')):
            return 0, 'series'

        score = 0
        reasons = []

        wanted_imdb = str(imdb or '').strip().lower()
        item_imdb = str(item.get('imdb_id') or '').strip().lower()
        imdb_match = bool(wanted_imdb and item_imdb and wanted_imdb == item_imdb)
        if imdb_match:
            score += 150
            reasons.append('imdb')

        clean_titles = set()
        wanted_words = []
        for title in titles or []:
            if not title:
                continue
            clean = cleantitle.get(title)
            if clean:
                clean_titles.add(clean)
            words = self._words(title)
            if words:
                wanted_words.append(words)

        item_titles = set()
        item_words = []
        for key in ['name', 'title', 'original_title']:
            value = item.get(key)
            if not value:
                continue
            clean = cleantitle.get(value)
            if clean:
                item_titles.add(clean)
            words = self._words(value)
            if words:
                item_words.append(words)

        for value in list(item_titles):
            stripped = re.sub(r'(unrated|extended|directorscut|germansub|uncut)$', '', value or '')
            if stripped:
                item_titles.add(stripped)

        title_score = 0
        if clean_titles.intersection(item_titles):
            title_score = 80
            reasons.append('title-exact')
        else:
            ratio = self._best_token_ratio(wanted_words, item_words)
            if ratio >= 0.84:
                title_score = 55
                reasons.append('title-token-%.2f' % ratio)
            elif ratio >= 0.66:
                title_score = 35
                reasons.append('title-token-%.2f' % ratio)
            elif self._loose_title_match(clean_titles, item_titles):
                title_score = 30
                reasons.append('title-loose')

        score += title_score
        if not imdb_match and title_score == 0:
            return 0, 'title-mismatch'

        item_year = self._year(item)
        try:
            if year and item_year:
                delta = abs(int(year) - int(item_year))
                if delta == 0:
                    score += 20
                    reasons.append('year')
                elif delta == 1:
                    score += 8
                    reasons.append('year+-1')
                elif delta <= 3:
                    score -= 5
                    reasons.append('year-delta-%s' % delta)
                else:
                    score -= 15
                    reasons.append('year-delta-%s' % delta)
        except Exception:
            pass

        return score, ','.join(reasons) or 'matched'

    def _movie_search_titles(self, titles):
        seen = set()
        result = []

        def add(value):
            value = html_unescape(str(value or '').strip())
            value = re.sub(r'\s+', ' ', value).strip(' -:')
            key = value.lower()
            if value and len(value) >= 2 and key not in seen:
                seen.add(key)
                result.append(value)

        for title in titles or []:
            title = html_unescape(str(title or '').strip())
            if not title:
                continue
            add(title)
            add(title.replace(' vs. ', ' vs ').replace(' Vs. ', ' Vs '))
            if ' - ' in title:
                add(title.split(' - ', 1)[0])
            if ':' in title:
                add(title.split(':', 1)[0])

            words = re.findall(r"[0-9A-Za-zÀ-ÿ]+", title)
            stop = {'the', 'a', 'an', 'der', 'die', 'das', 'ein', 'eine', 'of', 'and', 'und'}
            significant = [word for word in words if word.lower() not in stop]
            if len(significant) >= 2:
                add(' '.join(significant))
            if len(significant) >= 3:
                add(' '.join(significant[-3:]))

        return result[:16]

    @staticmethod
    def _words(value):
        return [
            word.lower()
            for word in re.findall(r"[0-9A-Za-zÀ-ÿ]+", html_unescape(str(value or '')))
            if word
        ]

    @staticmethod
    def _best_token_ratio(wanted_titles, item_titles):
        best = 0.0
        for wanted in wanted_titles:
            wanted_set = set(wanted)
            if not wanted_set:
                continue
            for current in item_titles:
                current_set = set(current)
                if not current_set:
                    continue
                common = len(wanted_set.intersection(current_set))
                ratio = (2.0 * common) / float(len(wanted_set) + len(current_set))
                if ratio > best:
                    best = ratio
        return best

    def _episode_videos(self, title_id, season, episode):
        if not title_id:
            return []

        season_num = int(season or 0)
        episode_num = int(episode or 0)
        season_url = self.season_link % (title_id, season_num)
        season_referer = self.base_link + '/titles/%s/season/%s' % (title_id, season_num)
        data = self._json(season_url, season_referer, 'seasonPage')
        episodes = []
        if isinstance(data.get('episodes'), dict):
            episodes = data.get('episodes', {}).get('data') or []

        target = None
        for candidate in episodes:
            try:
                if int(candidate.get('episode_number') or 0) == episode_num:
                    target = candidate
                    break
            except Exception:
                continue

        if not target:
            log_utils.log('[MOFLIX-HAR] episode not found S%sE%s in seasonPage' % (season_num, episode_num), log_utils.LOGINFO)
            return []

        primary = target.get('primary_video') if isinstance(target.get('primary_video'), dict) else {}
        video_id = primary.get('id')
        if not video_id:
            log_utils.log('[MOFLIX-HAR] no primary video S%sE%s' % (season_num, episode_num), log_utils.LOGINFO)
            return []

        watch_url = self.watch_link % video_id
        watch = self._json(watch_url, self.base_link + '/watch/%s' % video_id, 'watchPage')

        videos = []
        seen_ids = set()
        for video in [watch.get('video')] + list(watch.get('alternative_videos') or []):
            if not isinstance(video, dict):
                continue
            try:
                if video.get('season_num') not in (None, '') and int(video.get('season_num')) != season_num:
                    continue
                if video.get('episode_num') not in (None, '') and int(video.get('episode_num')) != episode_num:
                    continue
            except Exception:
                continue
            key = video.get('id') or video.get('src')
            if not key or key in seen_ids:
                continue
            seen_ids.add(key)
            if video.get('src'):
                videos.append(video)

        log_utils.log('[MOFLIX-HAR] S%sE%s watch_id=%s mirrors=%s' % (
            season_num, episode_num, video_id, len(videos)
        ), log_utils.LOGINFO)
        return videos

    def _add_videos(self, videos):
        for video in videos or []:
            if not isinstance(video, dict):
                continue

            original_url = html_unescape(str(video.get('src') or '').strip())
            if not original_url or original_url in self._seen:
                continue
            if 'youtube.' in original_url.lower() or 'youtu.be/' in original_url.lower():
                continue
            self._seen.add(original_url)

            original_host = (urlparse(original_url).hostname or '').lower()
            if original_host == 'moflix-stream.link':
                log_utils.log('[MOFLIX-FAST] slow failing host skipped: %s' % original_host, log_utils.LOGINFO)
                continue

            if self._is_moflix_hls(original_url) and not self._direct_hls_usable(original_url):
                log_utils.log('[MOFLIX-XVAULT] unusable direct HLS skipped: %s' % original_host, log_utils.LOGINFO)
                continue

            quality = self._quality('%s %s' % (video.get('quality') or '', original_url))
            language = self._language(video.get('language'), video.get('quality'), video.get('name'), original_url)
            mirror_prio = self._mirror_priority(original_url)

            started = time.time()
            is_blocked, hoster, resolved_url, prio_hoster = isBlockedHoster(original_url)
            try:
                log_utils.log('[MOFLIX-HOST-TIMING] %s | %.2fs | blocked=%s | resolver=%s' % (
                    original_host or original_url,
                    time.time() - started,
                    str(is_blocked),
                    str(hoster)
                ), log_utils.LOGINFO)
            except Exception:
                pass

            if is_blocked or not resolved_url:
                continue

            hoster_text = str(hoster or '')
            if 'poophq' in hoster_text or 'doods.to' in hoster_text:
                hoster = 'Veev'
            elif 'moflix-stream.click' in hoster_text:
                hoster = 'FileLions'
            elif 'moflix-stream.day' in hoster_text:
                hoster = 'VidGuard'

            try:
                prio_hoster = min(int(prio_hoster), int(mirror_prio))
            except Exception:
                prio_hoster = mirror_prio

            self.sources.append({
                'source': hoster,
                'quality': quality,
                'language': language,
                'url': resolved_url,
                'info': self._info(video),
                'direct': True,
                'priority': int(self.priority),
                'prioHoster': prio_hoster
            })

    def _cloudscraper_session(self, force=False):
        """Build one persistent Cloudscraper session for Moflix.

        Test8 only: no cookie values are written to kodi.log.
        """
        try:
            if self._cf_scraper is not None and self._cf_bootstrap_done and not force:
                return self._cf_scraper

            try:
                import cloudscraper2 as cloudscraper
                log_utils.log('[MOFLIX-CLOUDSCRAPER2] import direct=ok module=cloudscraper2', log_utils.LOGINFO)
            except Exception as first_exc:
                # Kodi can report script.module.cloudscraper as installed without
                # exposing its lib directory to this worker thread. Resolve the
                # add-on path explicitly; this is portable on Windows/Android.
                try:
                    import os
                    import sys
                    import xbmcaddon
                    try:
                        import xbmcvfs
                        translate = xbmcvfs.translatePath
                    except Exception:
                        import xbmc
                        translate = xbmc.translatePath

                    addon_path = translate(xbmcaddon.Addon('script.module.cloudscraper').getAddonInfo('path'))
                    candidates = [
                        os.path.join(addon_path, 'lib'),
                        os.path.join(addon_path, 'resources', 'lib'),
                        addon_path,
                    ]
                    added = 0
                    for candidate in candidates:
                        if candidate and os.path.isdir(candidate) and candidate not in sys.path:
                            sys.path.insert(0, candidate)
                            added += 1
                    try:
                        import cloudscraper2 as cloudscraper
                        module_name = 'cloudscraper2'
                    except Exception:
                        import cloudscraper
                        module_name = 'cloudscraper'
                    log_utils.log('[MOFLIX-CLOUDSCRAPER2] import fallback=ok module=%s paths_added=%s' % (module_name, added), log_utils.LOGINFO)
                except Exception as exc:
                    log_utils.log('[MOFLIX-CLOUDSCRAPER2] import failed direct=%s fallback=%s' % (first_exc, exc), log_utils.LOGINFO)
                    return None

            try:
                version = getattr(cloudscraper, '__version__', '?')
            except Exception:
                version = '?'

            try:
                scraper = _MoflixTest12Session()
                log_utils.log('[MOFLIX-TEST11] requests.Session transport active', log_utils.LOGINFO)
            except Exception:
                scraper = _MoflixTest12Session()
                log_utils.log('[MOFLIX-TEST11] requests.Session transport active', log_utils.LOGINFO)

            # Keep the UA generated by cloudscraper. A Cloudflare clearance, if
            # obtained, can be tied to that UA/TLS session.
            scraper.headers.update({
                'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,*/*;q=0.8',
                'Accept-Language': 'de-DE,de;q=0.9,en-US;q=0.8,en;q=0.7',
                'Cache-Control': 'no-cache',
                'Pragma': 'no-cache',
                'Referer': self.base_link + '/',
            })

            response = scraper.get(self.base_link + '/', timeout=12, allow_redirects=True)
            names = set(cookie.name for cookie in scraper.cookies)
            cf_clear = '_cf_clearance' in names or 'cf_clearance' in names
            xsrf = 'XSRF-TOKEN' in names
            sess = 'moflix_stream_session' in names
            mitigated = response.headers.get('cf-mitigated', '') if response is not None else ''
            server = response.headers.get('server', '') if response is not None else ''
            log_utils.log(
                '[MOFLIX-CLOUDSCRAPER2] bootstrap version=%s status=%s cookies=%s clearance=%s xsrf=%s session=%s mitigated=%s server=%s' % (
                    version,
                    getattr(response, 'status_code', ''),
                    len(names),
                    'yes' if cf_clear else 'no',
                    'yes' if xsrf else 'no',
                    'yes' if sess else 'no',
                    mitigated or '-',
                    server or '-'
                ),
                log_utils.LOGINFO
            )
            self._cf_scraper = scraper
            self._cf_bootstrap_done = True
            return scraper
        except Exception as exc:
            log_utils.log('[MOFLIX-CLOUDSCRAPER2] bootstrap error=%s' % exc, log_utils.LOGINFO)
            self._cf_scraper = None
            self._cf_bootstrap_done = False
            return None

    def _cloudscraper_json(self, url, referer, label='api', force=False):
        try:
            scraper = self._cloudscraper_session(force=force)
            if scraper is None:
                return None

            # Read the current Laravel cookies from the same persistent session.
            xsrf_raw = scraper.cookies.get('XSRF-TOKEN', domain=None, path=None) or ''
            xsrf = unquote(xsrf_raw) if xsrf_raw else ''
            headers = {
                'Accept': 'application/json, text/plain, */*',
                'Accept-Language': 'de-DE,de;q=0.9,en-US;q=0.8,en;q=0.7',
                'Referer': referer or self.base_link + '/',
                'X-Requested-With': 'XMLHttpRequest',
            }
            if xsrf:
                headers['X-XSRF-TOKEN'] = xsrf

            response = scraper.get(url, headers=headers, timeout=12, allow_redirects=True)
            mitigated = response.headers.get('cf-mitigated', '')
            ctype = response.headers.get('content-type', '')
            names = set(cookie.name for cookie in scraper.cookies)
            cf_clear = '_cf_clearance' in names or 'cf_clearance' in names
            preview = re.sub(r'\s+', ' ', response.text or '')[:120]
            log_utils.log(
                '[MOFLIX-CLOUDSCRAPER2] %s status=%s clearance=%s mitigated=%s type=%s bytes=%s payload=%s' % (
                    label,
                    response.status_code,
                    'yes' if cf_clear else 'no',
                    mitigated or '-',
                    ctype or '-',
                    len(response.content or b''),
                    preview
                ),
                log_utils.LOGINFO
            )
            if response.status_code != 200:
                return None
            try:
                data = response.json()
            except Exception:
                data = json.loads(response.text)
            return data if isinstance(data, dict) else None
        except Exception as exc:
            log_utils.log('[MOFLIX-CLOUDSCRAPER2] %s error=%s' % (label, exc), log_utils.LOGINFO)
            return None

    def _bootstrap_session(self, force=False):
        try:
            if (not force and self._xsrf_token and self._cookie_header and
                    (time.time() - self._session_bootstrap_at) < 1800):
                return True

            request = cRequestHandler(self.base_link + '/', caching=False, ignoreErrors=True)
            request.addHeaderEntry('User-Agent', UA)
            request.addHeaderEntry('Accept', 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,*/*;q=0.8')
            request.addHeaderEntry('Accept-Language', 'de-DE,de;q=0.9,en-US;q=0.8,en;q=0.7')
            request.addHeaderEntry('Sec-Fetch-Site', 'none')
            request.addHeaderEntry('Sec-Fetch-Mode', 'navigate')
            request.addHeaderEntry('Sec-Fetch-Dest', 'document')
            request.request()

            try:
                status = str(request.getStatus() or '')
            except Exception:
                status = ''

            cookies = {}
            headers = None
            try:
                headers = request.getResponseHeader()
            except Exception:
                headers = None
            set_cookie_values = []
            if headers:
                try:
                    set_cookie_values = headers.get_all('Set-Cookie') or []
                except Exception:
                    try:
                        raw = headers.get('Set-Cookie')
                        if raw:
                            set_cookie_values = [raw]
                    except Exception:
                        pass
            for raw in set_cookie_values:
                try:
                    first = str(raw).split(';', 1)[0]
                    if '=' in first:
                        name, value = first.split('=', 1)
                        cookies[name.strip()] = value.strip()
                except Exception:
                    continue

            # Fallback to the requestHandler's persisted cookie jar.
            for name in ('XSRF-TOKEN', 'moflix_stream_session'):
                if cookies.get(name):
                    continue
                try:
                    obj = request.getCookie(name)
                    if obj:
                        cookies[name] = str(obj.value or '')
                except Exception:
                    pass

            xsrf_raw = cookies.get('XSRF-TOKEN', '')
            session_raw = cookies.get('moflix_stream_session', '')
            self._xsrf_token = unquote(xsrf_raw) if xsrf_raw else ''
            cookie_parts = []
            if xsrf_raw:
                cookie_parts.append('XSRF-TOKEN=' + xsrf_raw)
            if session_raw:
                cookie_parts.append('moflix_stream_session=' + session_raw)
            self._cookie_header = '; '.join(cookie_parts)
            self._session_bootstrap_at = time.time()

            log_utils.log('[MOFLIX-XSRF] bootstrap status=%s xsrf=%s session=%s cookies=%s' % (
                status,
                'yes(%s)' % len(self._xsrf_token) if self._xsrf_token else 'no',
                'yes(%s)' % len(session_raw) if session_raw else 'no',
                len(set_cookie_values)
            ), log_utils.LOGINFO)
            return bool(self._xsrf_token)
        except Exception as exc:
            log_utils.log('[MOFLIX-XSRF] bootstrap error=%s' % exc, log_utils.LOGINFO)
            return False

    def _json(self, url, referer, label='api'):
        # TEST8: first try a persistent cloudscraper session. If it cannot pass
        # the managed challenge, retain the Test7 XSRF path for diagnostics.
        try:
            cf_data = self._cloudscraper_json(url, referer, label)
            if isinstance(cf_data, dict):
                log_utils.log('[MOFLIX-CLOUDSCRAPER2] %s JSON OK' % label, log_utils.LOGINFO)
                return cf_data
            self._bootstrap_session()
            request = cRequestHandler(url, caching=False, ignoreErrors=True)
            request.addHeaderEntry('User-Agent', UA)
            request.addHeaderEntry('Accept', 'application/json')
            request.addHeaderEntry('Accept-Language', 'de-DE,de;q=0.9,en-US;q=0.8,en;q=0.7')
            request.addHeaderEntry('Referer', referer or self.base_link + '/')
            request.addHeaderEntry('Sec-Fetch-Site', 'same-origin')
            request.addHeaderEntry('Sec-Fetch-Mode', 'cors')
            request.addHeaderEntry('Sec-Fetch-Dest', 'empty')
            request.addHeaderEntry('sec-ch-ua', '"Not=A?Brand";v="99", "Google Chrome";v="151", "Chromium";v="151"')
            request.addHeaderEntry('sec-ch-ua-mobile', '?0')
            request.addHeaderEntry('sec-ch-ua-platform', '"Windows"')
            request.addHeaderEntry('X-Requested-With', 'XMLHttpRequest')
            if self._xsrf_token:
                request.addHeaderEntry('X-XSRF-TOKEN', self._xsrf_token)
            if self._cookie_header:
                request.addHeaderEntry('Cookie', self._cookie_header)
            payload = request.request()
            try:
                status = str(request.getStatus() or '')
            except Exception:
                status = ''
            preview = re.sub(r'\s+', ' ', str(payload or ''))[:120]
            log_utils.log('[MOFLIX-HAR] %s status=%s payload=%s' % (label, status, preview), log_utils.LOGINFO)
            if status == '403' or 'CLOUDFLARE-SCHUTZ' in str(payload or ''):
                # One fresh session bootstrap/retry in case Moflix rotated the token.
                if self._bootstrap_session(force=True):
                    retry = cRequestHandler(url, caching=False, ignoreErrors=True)
                    retry.addHeaderEntry('User-Agent', UA)
                    retry.addHeaderEntry('Accept', 'application/json')
                    retry.addHeaderEntry('Accept-Language', 'de-DE,de;q=0.9,en-US;q=0.8,en;q=0.7')
                    retry.addHeaderEntry('Referer', referer or self.base_link + '/')
                    retry.addHeaderEntry('Sec-Fetch-Site', 'same-origin')
                    retry.addHeaderEntry('Sec-Fetch-Mode', 'cors')
                    retry.addHeaderEntry('Sec-Fetch-Dest', 'empty')
                    retry.addHeaderEntry('sec-ch-ua', '"Not=A?Brand";v="99", "Google Chrome";v="151", "Chromium";v="151"')
                    retry.addHeaderEntry('sec-ch-ua-mobile', '?0')
                    retry.addHeaderEntry('sec-ch-ua-platform', '"Windows"')
                    retry.addHeaderEntry('X-Requested-With', 'XMLHttpRequest')
                    retry.addHeaderEntry('X-XSRF-TOKEN', self._xsrf_token)
                    if self._cookie_header:
                        retry.addHeaderEntry('Cookie', self._cookie_header)
                    payload = retry.request()
                    try:
                        status = str(retry.getStatus() or '')
                    except Exception:
                        status = ''
                    log_utils.log('[MOFLIX-XSRF] retry %s status=%s' % (label, status), log_utils.LOGINFO)
            if not payload:
                return {}
            data = json.loads(payload)
            return data if isinstance(data, dict) else {}
        except Exception as exc:
            log_utils.log('[MOFLIX-HAR] %s error=%s url=%s' % (label, exc, url), log_utils.LOGINFO)
            return {}

    def _title_referer(self, item):
        try:
            item_id = item.get('id')
            name = str(item.get('name') or item.get('title') or '').strip().lower()
            slug = re.sub(r'[^0-9a-z]+', '-', name).strip('-') or 'title'
            return self.base_link + '/titles/%s/%s' % (item_id, slug)
        except Exception:
            return self.base_link + '/'

    def _request_text(self, url, referer=None):
        try:
            request = cRequestHandler(url)
            request.addHeaderEntry('User-Agent', UA)
            request.addHeaderEntry('Accept', '*/*')
            request.addHeaderEntry('Accept-Language', 'de-DE,de;q=0.9,en;q=0.8')
            request.addHeaderEntry('Referer', referer or self.base_link + '/')
            request.addHeaderEntry('Origin', self.base_link)
            payload = request.request()
            try:
                status = str(request.getStatus() or '')
            except Exception:
                status = '200' if payload else ''
            return payload or '', status
        except Exception:
            return '', ''

    def _direct_hls_usable(self, url):
        try:
            master, status = self._request_text(url, self.base_link + '/')
            if status not in ['', '200', '301', '302'] or '#EXTM3U' not in master:
                return False
            child = self._first_child_playlist(master)
            if not child:
                return True
            child_url = urljoin(url, child)
            payload, child_status = self._request_text(child_url, url)
            return bool(payload) and child_status in ['', '200', '301', '302']
        except Exception:
            return False

    @staticmethod
    def _first_child_playlist(master):
        for line in (master or '').splitlines():
            line = line.strip()
            if not line or line.startswith('#'):
                continue
            if '.m3u' in line.lower():
                return line
        return ''

    def _search_titles(self, titles):
        seen = set()
        result = []
        for title in titles or []:
            title = html_unescape(str(title or '').strip())
            if not title:
                continue
            variants = [title]
            if ' - ' in title:
                variants.append(title.split(' - ', 1)[0].strip())
            if ':' in title:
                variants.append(title.split(':', 1)[0].strip())
            for variant in variants:
                key = variant.lower()
                if variant and key not in seen:
                    seen.add(key)
                    result.append(variant)
        return result[:8]

    @staticmethod
    def _loose_title_match(clean_titles, item_titles):
        for wanted in clean_titles:
            for current in item_titles:
                if not wanted or not current or min(len(wanted), len(current)) < 5:
                    continue
                if wanted in current or current in wanted:
                    return True
        return False

    @staticmethod
    def _year(item):
        for key in ['year', 'release_date', 'first_air_date']:
            value = item.get(key)
            match = re.search(r'\b(19\d{2}|20\d{2})\b', str(value or ''))
            if match:
                return match.group(1)
        return ''

    @staticmethod
    def _quality(value):
        text = str(value or '').lower()
        if '2160' in text or '4k' in text:
            return '4K'
        if '1440' in text:
            return '1440p'
        if '1080' in text:
            return '1080p'
        if '720' in text:
            return '720p'
        if '480' in text or '360' in text or 'sd' in text:
            return 'SD'
        return 'HD'

    @staticmethod
    def _language(explicit, *values):
        explicit = str(explicit or '').strip().lower()
        if explicit in ['de', 'deu', 'ger', 'german', 'deutsch']:
            return 'de'
        if explicit in ['en', 'eng', 'english', 'englisch']:
            return 'en'
        if explicit in ['multi', 'multilang', 'dual', 'dl']:
            return 'multi'
        text = ' '.join(str(value or '').lower() for value in values)
        tokens = set(re.findall(r'[a-z]+', text))
        if 'multi' in tokens or 'dual' in tokens or 'dl' in tokens or ('de' in tokens and 'en' in tokens):
            return 'multi'
        if any(token in tokens for token in ['de', 'deu', 'ger', 'german', 'deutsch']):
            return 'de'
        if any(token in tokens for token in ['en', 'eng', 'english', 'englisch']):
            return 'en'
        return explicit or 'unknown'

    @staticmethod
    def _info(video):
        values = []
        for key in ['name', 'quality', 'type', 'origin']:
            value = str(video.get(key) or '').strip()
            if value and value.lower() not in ['none', 'null']:
                values.append(value)
        return ' | '.join(values)

    @staticmethod
    def _is_moflix_hls(url):
        try:
            clean_url = str(url or '').split('|', 1)[0].split('?', 1)[0].lower()
            host = (urlparse(clean_url).hostname or '').lower()
            return clean_url.endswith(('.m3u8', '.m3u')) and (
                host.endswith('.moflix-stream.day') or
                host.endswith('.moflix-stream.xyz') or
                host in ['moflix-stream.day', 'moflix-stream.xyz']
            )
        except Exception:
            return False

    @staticmethod
    def _mirror_priority(url):
        host = (urlparse(str(url or '').split('|', 1)[0]).hostname or '').lower()
        if host == 'veev.to':
            return 25
        if host == 'moflix-stream.click':
            return 35
        if host in ['moflix.rpmplay.xyz', 'moflix.upns.xyz']:
            return 45
        if host == 'moflix-stream.link':
            return 55
        if host == 'gupload.xyz':
            return 70
        return 100
