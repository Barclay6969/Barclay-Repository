# -*- coding: utf-8 -*-
import os
import xbmc
import xbmcaddon
import xbmcgui
import xbmcvfs

ADDON = xbmcaddon.Addon()
VERSION = ADDON.getAddonInfo('version')
PROFILE = xbmcvfs.translatePath(ADDON.getAddonInfo('profile'))
ADDON_PATH = xbmcvfs.translatePath(ADDON.getAddonInfo('path'))
MARKER = os.path.join(PROFILE, 'changelog_seen_version.txt')
CHANGELOG = os.path.join(ADDON_PATH, 'changelog.txt')

def _read(path):
    try:
        if not xbmcvfs.exists(path):
            return ''
        f = xbmcvfs.File(path)
        data = f.read()
        f.close()
        return data or ''
    except Exception:
        return ''

def _write(path, data):
    try:
        if not xbmcvfs.exists(PROFILE):
            xbmcvfs.mkdirs(PROFILE)
        f = xbmcvfs.File(path, 'w')
        f.write(data)
        f.close()
    except Exception:
        pass

monitor = xbmc.Monitor()

# Kodi zuerst vollständig hochfahren lassen.
if not monitor.waitForAbort(6):
    last_seen = _read(MARKER).strip()
    if last_seen != VERSION:
        changelog = _read(CHANGELOG).strip()
        if changelog:
            try:
                xbmcgui.Dialog().textviewer(
                    'xShip – Neuigkeiten / Changelog',
                    changelog
                )
            except Exception:
                pass
        _write(MARKER, VERSION)
