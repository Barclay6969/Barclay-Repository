Terror-Lite Omega 1.1.8 - Full Height Glass Selector

This build is based on the existing tested 1.1.7 release.
The main-menu glass selection is now 110 units high, top offset -4.
Width remains exactly 568 units; the same listselect_fo.png texture
and $VAR[HighlightBarColor] are used.

No user profiles, add-ons, widgets or skin settings are modified.

Install in Kodi via Add-ons > Install from ZIP.
Keep the known-working 1.1.4 ZIP as an independent backup.
