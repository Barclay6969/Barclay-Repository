# -*- coding: utf-8 -*-
"""TerrorLite one-time FilmPalast Skin Shortcuts migration.
Runs from Home.xml before the Skin Shortcuts menu build. Does not alter other menus.
"""
import json
import os
import traceback
import xbmc
import xbmcvfs

FILMPALAST = [['mainmenu', 'plugin.video.filmpalast.ex', 'background', 'https://bladedesign.ch/dir/repo/INFINITY/Kodi4black.png'], ['mainmenu', 'plugin.video.filmpalast.ex', 'backgroundName', 'https://bladedesign.ch/dir/repo/INFINITY/Kodi4black.png'], ['mainmenu', 'plugin.video.filmpalast.ex', 'widget', 'Addon'], ['mainmenu', 'plugin.video.filmpalast.ex', 'widgetName', 'FilmPalast - Neue Filme'], ['mainmenu', 'plugin.video.filmpalast.ex', 'widgetType', 'videos'], ['mainmenu', 'plugin.video.filmpalast.ex', 'widgetTarget', 'videos'], ['mainmenu', 'plugin.video.filmpalast.ex', 'widgetPath', 'plugin://plugin.video.filmpalast.ex/?url=https%3A%2F%2Ffilmpalast.to%2Fmovies%2Fnew&mode=1&reload=$INFO[Window(Home).Property(widgetreload-movies)]'], ['mainmenu', 'plugin.video.filmpalast.ex', 'widgetStyle', 'Extended Panel'], ['mainmenu', 'plugin.video.filmpalast.ex', 'widgetPanelInfo', 'Enabled'], ['mainmenu', 'plugin.video.filmpalast.ex', 'widgetCase', 'Glass'], ['mainmenu', 'plugin.video.filmpalast.ex', 'widget.2', 'Addon'], ['mainmenu', 'plugin.video.filmpalast.ex', 'widgetName.2', 'TMDb Helper - Diese Woche im Trend'], ['mainmenu', 'plugin.video.filmpalast.ex', 'widgetType.2', 'videos'], ['mainmenu', 'plugin.video.filmpalast.ex', 'widgetTarget.2', 'videos'], ['mainmenu', 'plugin.video.filmpalast.ex', 'widgetPath.2', 'plugin://plugin.video.themoviedb.helper/?info=trending_week&tmdb_type=tv&reload=%24INFO%5BWindow%28Home%29.Property%28TMDbHelper.Widgets.Reload%29%5D&widget=true'], ['mainmenu', 'plugin.video.filmpalast.ex', 'widgetStyle.2', 'Compact Panel'], ['mainmenu', 'plugin.video.filmpalast.ex', 'widgetPanelInfo.2', 'Enabled'], ['mainmenu', 'plugin.video.filmpalast.ex', 'widgetCase.2', 'Glass'], ['mainmenu', 'plugin.video.filmpalast.ex', 'widgetBack', 'None'], ['mainmenu', 'plugin.video.filmpalast.ex', 'widgetBack.2', 'None'], ['mainmenu', 'plugin.video.filmpalast.ex', 'widgetTitle', 'On Focus']]
TARGET = 'plugin.video.filmpalast.ex'
LEGACY = 'plugin.video.xstream'


def _path(value):
    return xbmcvfs.translatePath(value)


def migrate():
    folder = _path('special://profile/addon_data/script.skinshortcuts/')
    path = os.path.join(folder, 'skin.terror.lite.properties')
    if not os.path.isdir(folder):
        os.makedirs(folder)
    if os.path.isfile(path):
        with open(path, 'rb') as stream:
            existing = json.loads(stream.read().decode('utf-8-sig'))
        if not isinstance(existing, list):
            raise ValueError('Unexpected Skin Shortcuts properties format')
    else:
        existing = []
    # The known obsolete xStream FilmPalast defaults are from the original
    # migrated menu. Do not remove unrelated properties or other menu entries.
    old_filmpalast = any(
        isinstance(x, list) and len(x) == 4 and x[:3] == ['mainmenu', LEGACY, 'widgetName']
        and x[3] == 'xStream - Neues' for x in existing
    )
    filtered = [x for x in existing if not (
        old_filmpalast and isinstance(x, list) and len(x) == 4
        and x[0] == 'mainmenu' and x[1] == LEGACY
    )]
    # Add only missing FilmPalast fields: never reset subsequent user choices.
    present = {x[2] for x in filtered if isinstance(x, list) and len(x) == 4
               and x[0] == 'mainmenu' and x[1] == TARGET}
    for setting in FILMPALAST:
        if setting[2] not in present:
            filtered.append(setting)
            present.add(setting[2])
    if filtered == existing:
        return
    temp = path + '.terrorlite.tmp'
    # A dated-once backup avoids irreversible changes on existing installations.
    if os.path.isfile(path):
        backup = path + '.terrorlite-before-filmpalast.bak'
        if not os.path.exists(backup):
            import shutil
            shutil.copy2(path, backup)
    with open(temp, 'wb') as stream:
        stream.write(json.dumps(filtered, indent=4, ensure_ascii=False).encode('utf-8'))
    os.replace(temp, path)
    hashpath = os.path.join(folder, 'skin.terror.lite.hash')
    if os.path.isfile(hashpath):
        try:
            os.remove(hashpath)
        except OSError:
            xbmc.log('[TerrorLite] Failed to invalidate Skin Shortcuts hash', xbmc.LOGWARNING)
    xbmc.log('[TerrorLite] FilmPalast shortcuts migrated', xbmc.LOGINFO)


if __name__ == '__main__':
    try:
        migrate()
    except Exception:
        xbmc.log('[TerrorLite] FilmPalast migration failed: ' + traceback.format_exc(), xbmc.LOGERROR)
    finally:
        # Ensure that the menu is always built, even when migration is blocked.
        xbmc.executebuiltin('RunScript(script.skinshortcuts,type=buildxml&mainmenuID=9000&levels=2&options=noGroups)')
