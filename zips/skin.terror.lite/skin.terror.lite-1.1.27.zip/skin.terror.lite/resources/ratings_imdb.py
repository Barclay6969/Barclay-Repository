# coding: utf-8
"""Terror-Lite Omega IMDb bridge, v1.1.15.

Only uses MDBList/OMDb keys configured in plugin.video.themoviedb.helper.
Does not log, display or store API keys. No extra service required.
"""
import json
import re
import sys
from urllib.parse import urlencode, quote
from urllib.request import Request, urlopen

import xbmc
import xbmcaddon
import xbmcgui

WINDOW_ID = 12003   # Kodi dialogvideoinfo / movieinformation
RATING_PROP = 'TerrorLite.IMDb.Rating'
SOURCE_PROP = 'TerrorLite.IMDb.Source'
PREFIX = '[TerrorLite IMDb] '


def log(msg, level=xbmc.LOGINFO):
    xbmc.log(PREFIX + msg, level)


def getinfo(label):
    try:
        return (xbmc.getInfoLabel(label) or '').strip()
    except Exception:
        return ''


def argmap():
    data = {}
    for arg in sys.argv[1:]:
        key, sep, val = arg.partition('=')
        if sep:
            data[key.lower().strip()] = val.strip()
    return data


def first_valid(values, pattern):
    for val in values:
        val = (val or '').strip()
        if re.fullmatch(pattern, val, re.IGNORECASE):
            return val
    return ''


def normalise_rating(value):
    try:
        f = float(str(value).replace(',', '.'))
    except (TypeError, ValueError):
        return ''
    if not 0 < f <= 10:
        return ''
    return '{:.1f}'.format(f)


def json_get(host, path, query):
    # Host is passed only by the two fixed call sites below.
    if host not in ('api.mdblist.com', 'www.omdbapi.com'):
        return {}
    url = 'https://{}{}?{}'.format(host, path, urlencode(query))
    req = Request(url, headers={'User-Agent': 'TerrorLite-Omega/1.1.15'})
    with urlopen(req, timeout=8) as reply:
        response = reply.read(350000)
    return json.loads(response.decode('utf-8'))


def mdblist_rating(key, tmdb, imdb):
    if not key or not (tmdb or imdb):
        return ''
    if tmdb:
        path = '/tmdb/movie/' + quote(tmdb, safe='')
    else:
        path = '/imdb/movie/' + quote(imdb, safe='')
    payload = json_get('api.mdblist.com', path, {'apikey': key})
    if not isinstance(payload, dict):
        return ''
    for item in payload.get('ratings', []):
        if isinstance(item, dict) and str(item.get('source', '')).lower() == 'imdb':
            score = normalise_rating(item.get('value'))
            if score:
                return score
    return ''


def omdb_rating(key, imdb, title, year):
    if not key or not (imdb or (title and year)):
        return ''
    query = {'apikey': key, 'type': 'movie'}
    if imdb:
        query['i'] = imdb
    else:
        query['t'], query['y'] = title, year
    payload = json_get('www.omdbapi.com', '/', query)
    if not isinstance(payload, dict) or payload.get('Response') == 'False':
        return ''
    if imdb and payload.get('imdbID') and payload['imdbID'].lower() != imdb.lower():
        return ''
    if not imdb and year and str(payload.get('Year', ''))[:4] != year:
        return ''
    return normalise_rating(payload.get('imdbRating'))


def ids(args):
    imdb = first_valid((
        args.get('imdb'), args.get('imdb2'), args.get('imdb3'),
        getinfo('ListItem.UniqueID(imdb)'),
        getinfo('ListItem.Property(IMDb_ID)'),
        getinfo('ListItem.IMDBNumber'),
        getinfo('Container(9143).ListItem.UniqueID(imdb)'),
        getinfo('Container(9143).ListItem.Property(IMDb_ID)'),
        getinfo('Container(9143).ListItem.IMDBNumber')),
        r'tt\d{5,12}')
    tmdb = first_valid((
        args.get('tmdb'), args.get('tmdb2'),
        getinfo('ListItem.UniqueID(tmdb)'),
        getinfo('ListItem.Property(TMDb_ID)'),
        getinfo('Container(9143).ListItem.UniqueID(tmdb)'),
        getinfo('Container(9143).ListItem.Property(TMDb_ID)')),
        r'[1-9]\d{0,11}')
    year = first_valid((args.get('year'), getinfo('ListItem.Year')),
                       r'(18|19|20|21)\d{2}')
    title = getinfo('ListItem.OriginalTitle') or getinfo('ListItem.Title')
    return imdb, tmdb, title, year


def main():
    args = argmap()
    window = xbmcgui.Window(WINDOW_ID)
    try:
        helper = xbmcaddon.Addon('plugin.video.themoviedb.helper')
        mdblist_key = (helper.getSetting('mdblist_apikey') or '').strip()
        omdb_key = (helper.getSetting('omdb_apikey') or '').strip()
    except Exception as exc:
        log('Cannot read TMDb Helper settings ({})'.format(type(exc).__name__))
        return

    # No key string is ever included in logs, even on HTTP failure.
    if not (mdblist_key or omdb_key):
        log('No IMDb source configured: neither MDBList nor OMDb key in TMDb Helper')
        return

    imdb, tmdb, title, year = ids(args)
    # Hidden TMDb Helper container 9143 fills asynchronously. Poll briefly
    # if the selected item has no IDs yet, especially for OMDb-only setups.
    if not (tmdb or imdb or (title and year)):
        monitor = xbmc.Monitor()
        for _ in range(10):
            if monitor.waitForAbort(0.5) or not xbmc.getCondVisibility('Window.IsVisible(movieinformation)'):
                return
            imdb, tmdb, title, year = ids(args)
            if tmdb or imdb or (title and year):
                break
    if not (tmdb or imdb or (title and year)):
        log('No usable movie ID or title/year passed to IMDb bridge')
        return

    # Mark currently selected movie. Clear on each dialog load in XML.
    marker = '{}|{}|{}'.format(tmdb, imdb, year)
    window.setProperty('TerrorLite.IMDb.Request', marker)
    sources = (
        ('MDBList', mdblist_rating, (mdblist_key, tmdb, imdb)),
        ('OMDb', omdb_rating, (omdb_key, imdb, title, year)),
    )
    for name, func, arguments in sources:
        if not arguments[0]:
            continue
        try:
            found = func(*arguments)
        except Exception as exc:
            log('{} request failed ({})'.format(name, type(exc).__name__), xbmc.LOGWARNING)
            continue
        if found:
            if (window.getProperty('TerrorLite.IMDb.Request') == marker
                    and xbmc.getCondVisibility('Window.IsVisible(movieinformation)')):
                window.setProperty(RATING_PROP, found)
                window.setProperty(SOURCE_PROP, name)
                log('IMDb rating available via {} (film TMDb id {})'.format(name, tmdb or 'unavailable'))
            return
    log('IMDb rating unavailable from configured providers (TMDb id {})'.format(tmdb or 'unavailable'))


if __name__ == '__main__':
    main()
