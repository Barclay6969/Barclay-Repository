TERROR-LITE OMEGA 1.1.4 — FILMPALAST
======================================

Dieses ZIP ist als Kodi-Skin-ZIP installierbar.
Skin-ID: skin.terror.lite (identisch mit 1.1.3)

VERHALTEN BEI UPDATE VON TERROR-LITE 1.1.3 AUF 1.1.4:
- Das vorhandene Nutzerprofil bleibt erhalten: Skin-Shortcuts-Menüs,
  Widgets, Hintergrundreferenzen, Farben und Filminfo-Einstellungen.
- In der Skin 1.1.4 sind ein Filmpalast-Menüpunkt sowie die beiden
  Standard-Widgetpfade als neue Defaults definiert.
- Bestehende Nutzerdaten in userdata/addon_data/ werden bei der Kodi-
  ZIP-Installation nicht überschrieben. Defaults überschreiben deshalb
  KEINE bereits gespeicherten Menüs/Widgets.
- Sonstige Dateien aus 1.1.3 sind unverändert. Kodi4black-Hintergrund,
  grosse Balken, Autoscroll/Autocomplete sowie TMDb/Trakt/RT bleiben
  vom 1.1.3-Stand erhalten.

WICHTIG: NUR die Installation der Skin-ZIP kann vorhandene persönliche
Shortcuts NICHT aus einem fremden Kodi-Profil importieren.

FALLS FILMPALAST NICHT SICHTBAR IST:
- Kodi komplett beenden.
- Das separat bereitgestellte Filmpalast-Profilpaket aus den vom Nutzer
  gelieferten Daten verwenden. Es enthält eine Anleitung und einen
  Windows-Installer, der vorhandene Daten vorher sichert.
- Nach dem ersten Start benötigen Widgets das installierte
  plugin.video.filmpalast.ex sowie plugin.video.themoviedb.helper.

WARNUNG ZU PRIVATEN DATEN:
Persönliche Kontodaten, URLs mit Benutzername/Passwort und komplette
Profildateien sind bewusst NICHT Bestandteil der Skin-ZIP.

Hinweis: XML-/Archivstruktur ist geprüft; ein Laufzeittest in Kodi 21.2
steht noch aus. Nicht über eine andere Skin-ID installieren, wenn die
Einstellungen von Terror-Lite beibehalten werden sollen.
