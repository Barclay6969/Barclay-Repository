Terror-Lite Omega 1.1.7
Refines the home menu glass selector from 1.1.6: same width, slightly taller height for better text embedding.
