# Terror-Lite Omega (Kodi 21.2) — Testport 1.1.0

Based on the uploaded Terror-Lite 1.0.1 skin, itself derived from Aeon Nox: SiLVO.

## Anpassungen fuer Kodi 21.2 Omega
- `xbmc.gui` auf `5.17.0` aktualisiert.
- Abhaengigkeiten auf die im offiziellen Omega-Repository verfuegbaren Versionen angepasst: Skin Shortcuts 2.0.3, Library Data Provider 0.4.2.
- Die entfernte `DialogFavourites.xml` durch `MyFavourites.xml` ersetzt (Kodi-21-Liste ID 50).
- Neue native Dialoge `DialogColorPicker.xml` und `DialogVideoManager.xml` fuer Omega hinzugefuegt.
- Nicht mehr vorhandene Bedingung `Player.DisplayAfterSeek` ersetzt.
- Alle originalen Bilder, Schriften, Widgets und Hintergrundmedien unveraendert belassen.

## Installieren / testen
1. In Kodi 21.2: Einstellungen > Add-ons > Aus ZIP-Datei installieren und diese ZIP waehlen.
2. Abhaengigkeiten ggf. aus dem offiziellen Kodi-Omega-Repository installieren lassen.
3. Unter Einstellungen > Oberflaeche > Skin den Skin **Terror Lite Omega** auswaehlen.
4. Hauptmenue, Filme, Favoriten, Filmversionen/Extras und Farbauswahl pruefen.

Wichtig: Dies ist ein statisch validierter Testport, **kein** in Kodi 21.2 ausgefuehrter Funktionstest. Externe Widgets/Erweiterungen koennen zusaetzliche Add-ons benoetigen. `service.library.data.provider` ist zwar in Omega verfuegbar, gilt aber als alt/unmaintained. Bei Abstuerzen bitte eine frische `kodi.log` bereitstellen.
