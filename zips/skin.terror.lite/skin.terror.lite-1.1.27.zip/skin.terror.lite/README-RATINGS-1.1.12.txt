Terror LiTE Omega 1.1.12 | SiLVO ratings source correction

Base: 1.1.11 (published version stays 1.1.9 in Barclay Repository).
Data sources (by the CURRENT movie identifier in the information window):
  9143 - plugin.video.themoviedb.helper/?info=details
  9144 - script.skin.info.service/?action=online
Both are standard Kodi plugin paths and contain NO user API keys.

IMDb: first native item rating, then TMDb Helper, then Skin Info Service.
Trakt: first native item rating, then TMDb Helper, then Skin Info Service.
Rotten Tomatoes: native property, helper critics %, then Skin Info Service critics %.
TMDb: native named rating, helper, Skin Info Service; only one badge per movie.

Existing menus, backgrounds, homepage widgets, Filmpalast and glass-selector
files are preserved exactly. This is a local build, not a repository release.

Provider availability: TMDb Helper and Skin Info Service must have configured
network access/API keys where required (OMDb or MDBList for IMDb/RT, Trakt).
An XML skin alone cannot supply data that the providers do not return.
