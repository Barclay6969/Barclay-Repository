Terror LiTE Omega 1.1.10 – Ratings-Test, NOT for repository release.
Based on published stable 1.1.9. No design changes.
Adds IMDb rating label and TMDb Helper hidden details list (ID 9143) inside movie info dialog.
Added fallbacks for Trakt/RT/TMDb and restarts the Skin Info Service if stopped.
For IMDb/RT to appear, TMDb Helper must have an appropriate configured OMDb key,
or an alternative metadata provider must supply the ratings. Trakt can require
provider configuration. The new details lookup only runs for movies when the dialog
is open; it may cause an initial delay. After testing, send screenshots and kodi.log.
Keep 1.1.9 as stable in Barclay Repository; do NOT publish this test build yet.
