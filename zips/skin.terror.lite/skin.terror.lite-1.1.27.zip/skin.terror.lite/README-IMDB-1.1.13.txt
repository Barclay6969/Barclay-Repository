Terror LiTE Omega 1.1.13 – IMDb source fallback (Kodi 21.2)

Based on the user-tested 1.1.12. Only IMDb fallback and addon version updated.

IMDb source priority:
1. Kodi current item (ListItem.Rating(imdb))
2. TMDb Helper current item IMDb_Rating or Rating.imdb
3. TMDb Helper details via hidden container 9143 (including native Rating(imdb))
4. Skin Info Service direct-ID online listing (container 9144 Rating.imdb)
5. Original SiLVO Embuary Helper local-library list 9142 (Rating(imdb))

Unconfigured providers cannot invent IMDb scores. For plugin movies, the
preferred provider is Skin Info Service with OMDb or MDBList enabled,
or TMDb Helper with a valid OMDb API key. Keep API keys only in local add-on
settings – never place keys in ZIP archives or the public Barclay Repository.

This build does NOT replace the stable published 1.1.9 repository version.
