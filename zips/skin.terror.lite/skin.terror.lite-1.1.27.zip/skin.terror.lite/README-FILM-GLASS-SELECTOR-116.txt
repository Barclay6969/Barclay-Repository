Terror-Lite Omega 1.1.6 – Filmglas-Selektor

Ausgangsbasis: funktionierende Terror-Lite Omega 1.1.4 + die 1.1.5-Selektorvariation.
Nur der Fokus-/Selektor im grossen horizontalen Hauptmenue ist geaendert.
Dort wird jetzt exakt dieselbe Textur und Akzentfarbe wie in der Filmliste
(listselect_fo.png + $VAR[HighlightBarColor], border=4) verwendet.
Die eigene hellblaue Overlay-Grafik aus 1.1.5 ist entfernt.
Alle Widgets, Hintergrundbilder, Menueaktionen, Filminfos und sonstigen Layouts
bleiben unveraendert. Es werden keine Benutzerprofildaten installiert.

Installation in Kodi 21.2: Add-ons > Aus ZIP-Datei installieren.
Die sichtbare Wirkung muss in Kodi selbst getestet werden.
Bei unerwartetem Ergebnis 1.1.4 wieder installieren.
