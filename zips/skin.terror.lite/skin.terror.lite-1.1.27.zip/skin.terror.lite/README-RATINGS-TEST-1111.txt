Terror LiTE Omega 1.1.11 - controlled ratings test build.
Changes compared with 1.1.10:
1. Hide the old, unlabelled default movie rating when it duplicates TMDb.
2. Restore SiLVO pattern for hidden TMDb Helper list 9143 (no fixed content URL).
3. Keep IMDb/Trakt/Rotten Tomatoes badges contingent on real metadata.
No API keys included. OMDb or MDBList credentials may be needed in TMDb Helper.
If additional ratings remain invisible, collect kodi.log and check TMDb Helper settings.
This is a LOCAL TEST. Leave Barclay Repository stable 1.1.9 unchanged.
