Terror-Lite Omega 1.1.5
Adds a subtle translucent blue glass highlight to the selected main menu bar item (LIVE-TV / FILM-TIME / FILMPALAST). Based on the confirmed working 1.1.4 build.
