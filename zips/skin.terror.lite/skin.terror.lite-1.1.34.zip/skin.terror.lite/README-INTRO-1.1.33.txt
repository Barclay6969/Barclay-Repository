TerrorLite 1.1.33 – KODI BUILD V8 Startintro

Das Startintro wird beim erstmaligen Wechsel auf 1.1.33 einmalig
auf EIN gesetzt (Skin-Einstellung Kusi.IntroDefaultApplied).
Anschliessend bleibt die Benutzerauswahl bei jedem Kodi-Neustart erhalten.

Einstellung: TerrorLite > Skin-Einstellungen > Hauptmenue > Start-Intro.

Video: special://skin/extras/intro-omega.mp4
Die separate Kodi-Splash-Anzeige bleibt unangetastet.

Enthaelt alle bisherigen offiziellen Verbesserungen bis Version 1.1.32:
Live-TV OSD: Pause-Fokus; Dateimanager-Kachel; PVR-Untertitel
standardmaessig AUS; Widget-Transparenz 75%; Glass-Preset und
weitere bestehende Skin-Optionen unveraendert.
